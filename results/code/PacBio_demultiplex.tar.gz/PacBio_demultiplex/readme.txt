README for PacBioDemultiplexer.jar

Usage:
java -jar PacBioDemultiplexer.jar -i reads_of_insert.fastq -b barcodes.txt -o name_of_run

barcodes.txt is provided as an example
This script will search for occurences of each submitted barcode and print out files for each. If there are dual barcodes, then seperate output files for each barcode will be produced and will need to be combined manually.

PacBioDemultiplexer.jar was compiled by Dr Burkhard Steuernagel (John Innes Centre) and Dr Oliver Furzer (TSL/UNC)