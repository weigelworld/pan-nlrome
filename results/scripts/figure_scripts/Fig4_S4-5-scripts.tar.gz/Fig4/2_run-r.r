#!/usr/bin/env Rscript

#Figure 4. Schematic karyogram produced with KaryoploteR
#Anchored OG projected coordinates in the Col-0 genome were manually deduced from webapollo, after identifying the respective anchoring locus (see co-ocurrance matrices, networka and UpSetR plots). 
#Minimum threshold of 10 co-occurrences is used to report placements. 
#Input files: 'r-input-files/*' 
#Output files: 1x .svg
#Labels position and chromosomes separations can be adjusted using inkscape 
#R dependencies: karyoploteR

#To install karyoplotter library
#if (!requireNamespace("BiocManager", quietly = TRUE))
#    install.packages("BiocManager")
#BiocManager::install("karyoploteR")

#Load library
library(karyoploteR)

##Input coordinates
TAIR9 <- toGRanges("r-input-files/TAIR9.txt")
CYTOBANDS <- toGRanges("r-input-files/cytobands-col0-nlrs.tsv")

#Plot parameters
plot.params <- getDefaultPlotParams(plot.type=2)
plot.params$data1height <- 400
plot.params$data2height <- 300
plot.params$ideogramheight <- 100
plot.params$bottommargin <- 100
plot.params$topmargin <- 200
plot.params$leftmargin <- 0.09
plot.params$rightmargin <- 0.005

#Create directory to save plots
dir.create(file.path("output-plots"), showWarnings = FALSE)

#Uncomment to generate .svg, or .png output
svg(filename="output-plots/OG-anchoring(10)_karyoploteR.svg",width=20, height=17)
#png(filename="output-plots/OG-anchoring(10)_karyoploteR.png", units="in", width=20, height=12, res=300)

#Plot TAIR genome with cytobands
kp <- plotKaryotype(genome=TAIR9, cytobands=CYTOBANDS, plot.params=plot.params, plot.type=2,cex=1.2)

#Add coordinates. Bug submitted to github issued. Fixed in current version.
kpAddBaseNumbers(kp, tick.dist=5000000, tick.len=10, tick.col="black", add.units=F, digits=0, minor.ticks=FALSE, minor.tick.dist=100000, minor.tick.len=5, cex=0.8,  clipping=F )

#Add centromere labels
markcen <- read.csv("r-input-files/markers-cen.tsv", sep='\t', header=T)
kpPlotMarkers(kp, data.panel=1, chr=markcen$chr, x=markcen$pos, labels=markcen$labels, text.orientation = "horizontal",r1=0.5, cex=0.9, adjust.label.position = TRUE, line.color = "red", label.color = "red", max.iter=1000)

#Add anchored OGs as markers
markog <- read.csv("r-input-files/markers-og.tsv", sep='\t', header=T)
kpPlotMarkers(kp, data.panel=2, chr=markog$chr, x=markog$pos,y=0.4, labels=markog$labels, text.orientation = "vertical", cex=0.9, adjust.label.position = TRUE, line.color = c("dodgerblue3","dodgerblue3","darkorange2","darkorange2","dodgerblue3","dodgerblue3","darkorange2","darkorange2","dodgerblue3","darkorange2","darkorange2","dodgerblue3","dodgerblue3","dodgerblue3","dodgerblue3","dodgerblue3","dodgerblue3","dodgerblue3","darkorange2","darkorange2","dodgerblue3","dodgerblue3","dodgerblue3","dodgerblue3"), label.color = c("dodgerblue3","dodgerblue3","darkorange2","darkorange2","dodgerblue3","dodgerblue3","darkorange2","darkorange2","dodgerblue3","darkorange2","darkorange2","dodgerblue3","dodgerblue3","dodgerblue3","dodgerblue3","dodgerblue3","dodgerblue3","dodgerblue3","darkorange2","darkorange2","dodgerblue3","dodgerblue3","dodgerblue3","dodgerblue3"), max.iter=1000)

#Add ATG labels as markers
markatg <- read.csv("r-input-files/markers-col0-nlrs.tsv", sep='\t', header=T)
kpPlotMarkers(kp, data.panel=1, chr=markatg$chr, x=markatg$pos, labels=markatg$labels, y=0.75, r1=0.3, ymin=0.2, text.orientation = "vertical", cex=0.8, line.color="black", label.color="black", label.dist=0.000001, label.margin=0.000001, max.iter=5000)

#Uncomment when generating .svg, or .png output files 
dev.off()

#check whether the unwanted 'Rplots.pdf' file exists and remove it
#file.exists("Rplots.pdf")
#file.remove("Rplots.pdf")
