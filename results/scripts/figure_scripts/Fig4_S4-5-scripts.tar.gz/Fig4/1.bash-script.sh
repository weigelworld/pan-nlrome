#!/bin/bash
#clear previous analysis data
#Dependencies: blast 2.6.0
printf "Removing output from previous run ................................................";
rm -r bash-output-files/ NLR-OGs/ nonNLR-OGs/ blast-output/ output-plots/
mkdir -p bash-output-files/og-contig-files/{same-contig-ogs,og-mappings,network}/ NLR-OGs/ nonNLR-OGs/ blast-output/;
printf " DONE\n"

input1="bash-input-files/transcript_metadata.tsv";
outallgns="bash-output-files/all_nonNLR.txt";
outnlrgns="bash-output-files/all_NLRs.txt";
outnets="bash-output-files/og-contig-files/network";
output2="bash-output-files/og-contig-files/og-mappings";

#Obtain an equivalence table between our internal RenSeq identifiers and TAIR. This table will allow to identify interesting genes and groups during synteny analysis. 
printf "TAIR-RenSeq 6909 identifiers equivalence (BlastDB+BlastP, check dependencies) ....";
#Build Blast database
makeblastdb -in bash-input-files/6909_renseq.fasta -input_type fasta -dbtype prot -title 6909renseq -out blast-output/6909renseq-db > blast-output/renseq-db-std.out 2> blast-output/renseq-db-std.err
makeblastdb -in bash-input-files/6909_it1.proteins.fasta -input_type fasta -dbtype prot -title 6909araport -out blast-output/6909araport-db > blast-output/araport-db-std.out 2> blast-output/araport-db-std.err

#Run BlastP
blastp -db blast-output/6909araport-db -query bash-input-files/6909_renseq.fasta -out blast-output/renseq-araport-blast -outfmt 6 -num_threads 3 > blast-output/renseq-blast-std.out 2> blast-output/renseq-blast-std.err
blastp -db blast-output/6909renseq-db -query bash-input-files/6909_it1.proteins.fasta -out blast-output/araport-renseq-blast -outfmt 6 -num_threads 3 > blast-output/araport-blast-std.out 2> blast-output/araport-blast-std.err
printf " DONE\n"

printf "Parsing 1:1 identifier assignments ...............................................";
#Appropriate sorting relies on the use of correct numeric environmental values. Decimal separators are different between Spanish and English. 
export LC_NUMERIC=en_US.UTF-8

# Make sure 1:1 assignments are obtained
sort -k1,1 -k12,12nr -k11,11g blast-output/araport-renseq-blast | sort -k1,1 -u | sort -k2,2 -k12,12nr -k11,11g | sort -k2,2 -u | awk '{print $2,$1}' | sort > araport-renseq_sorted_all_2_eq.tbl
sort -k1,1 -k12,12nr -k11,11g blast-output/renseq-araport-blast | sort -k1,1 -u | sort -k2,2 -k12,12nr -k11,11g | sort -k2,2 -u | awk '{print $1,$2}' | sort > renseq-araport_sorted_all_2_eq.tbl
comm -12 araport-renseq_sorted_all_2_eq.tbl renseq-araport_sorted_all_2_eq.tbl > bash-output-files/6909_RenSeq-TAIR_equiv.txt
comm -3 araport-renseq_sorted_all_2_eq.tbl renseq-araport_sorted_all_2_eq.tbl | sed 's/\t//g' | sort > bash-output-files/one-way-blasts.tbl
rm araport-renseq_sorted_all_2_eq.tbl renseq-araport_sorted_all_2_eq.tbl
#In common there are 514 gene identifiers with an unique 1:1 assignment in the two way blast. How many of those are NLRs?
#File is saved in renseq-araport_sorted_all_2_eq_final_514.tbl
#awk -F'[\t|]' '$1 ~ /^ATH/ {print $2}' bash-input-files/SITable-Genes_modif.tab | sort | while read line; do gene=`echo "6909|$line"`; awk -v l="$gene" '$2 == l {print $0}' bash-output-files/6909_RenSeq-TAIR_equiv.txt; done | wc -l
#198 out of 206 NLRs
#Idependently, we also used CRB Blast and obtained 199 equivalences. (results are stored in {crb_inparalogs.abc,crb_orthologs.abc,mcl_out.all.abc.I15})
#Current limitation for placement analysis is that we are missing 8 RenSeq 6909 NLRs not complying with the stringent 1:1 reciprocal best blast hit.
#Equivalence table for 6909 RenSeq-TAIR lives in: bash-output-files/6909_RenSeq-TAIR_equiv.txt
printf " DONE\n"

#Parse nlrome.refined.groups (NLR OGs) into separate files
printf "Parsing refined NLR OGs ..........................................................";
cat bash-input-files/nlrome.refined.groups | while read line; 
do
   ogn=`echo $line | awk '{print $1}'`;
   ogo=`echo $line | awk '{print $2}'`;
   gen=`echo $line | awk '{$1=$2=$3=$4=""; print $0}' | sed 's/ /\n/g' | sed '/^\s*$/d' | sort`;
   echo "$gen" > NLR-OGs/"$ogn".group;
done
rm NLR-OGs/id.new.group; #header in line 3 producing a header-containing file has to be removed
printf " DONE\n";

#Parse non-nlrome.filtered.groups (non-NLR OGs) into separate files
printf "Parsing nonNLR OGs ...............................................................";
cat bash-input-files/non-nlrome.filtered.groups | while read line; 
do
   ogn=`echo $line | awk '{print $1}'`;
   ogo=`echo $line | awk '{print $2}'`;
   gen=`echo $line | awk '{$1=$2=$3=$4=""; print $0}' | sed 's/ /\n/g' | sed '/^\s*$/d' | sort`;
   echo "$gen" > nonNLR-OGs/"$ogn".group;
done
rm nonNLR-OGs/id.new.group; #header in line 3 producing a header-containing file has to be removed
printf " DONE\n";

#####Location of all annotated non-NLRs (multiple steps here)
#All transcripts parsed from gff files
printf "Parsing GFF's ....................................................................";
awk -F'[;=\t]' '$3 == "mRNA" {print $10}' bash-input-files/gff/*.gff | sed 's/ID=//g' | sort -u | awk '$1 !~ /^CRUB|^ALYR/ {print }' | while read line; 
do 
  acc=`echo "$line" | awk -F\| '{print $1}'`; 
  if [ "$acc" == "6909" ]; 
  then 
    gene=`awk -v l=$line '$1 == l {print $2}' bash-output-files/6909_RenSeq-TAIR_equiv.txt`; 
    if [ -z "$gene" ]; 
    then 
      gene="$line"; 
    fi; 
  else 
    gene=$line; 
  fi; 
  echo "$gene"; 
done | sort > "$outallgns";
printf " DONE\n";

#Use comm/diff to define nonNLRs
#NLRs
awk 'NR>1 && $1 !~ /^CRUB|^ALYR|^6909\|T/ {print $1}' "$input1" | sort > "$outnlrgns";
#Non-NLRs
comm -23 "$outallgns" "$outnlrgns" | sort > bash-output-files/non_nlr_genes.txt;
#####

printf "Initiating gene linkage analysis (> 4h runtime) ..................................";
for file in NLR-OGs/*.group; 
do 
  og=$(basename $file); og=${og/.group/};
  printf "OG\tNLR\tNUMB_NLR\tACC\tCONTIG\tCONTIG_GENES\tNUMB_CONTIG_GENES\tCONTIG_NLRS\tNUMB_CONTIG_NLRS\tCONTIG_NLR_OGs\tNUMB_CONTIG_NLR_OGs\tCONTIG_NON-NLRS\tNUMB_CONTIG_NON-NLRS\tCONTIG_NON-NLR_OGs\tNUMB_CONTIG_NON-NLR_OGs\n" > bash-output-files/og-contig-files/same-contig-ogs/"$og".tsv;	#Print Header
  awk -F'\t' '$1 !~ /^ALYR|^CRUB/ {print }' "$file" | while read line;	#Read line by line each OG, exclude CRUB and ALYR genes
  do 
    acc=`echo "$line" | awk -F\| '{print $1}'`;
    gene=`echo "$line" | awk -F\| '{print $2}'`;
    
    if [ $acc == "6909" ]; 
    then	#6909 tigs in gff are for RenSeq gene identifiers. Call identifier from Araport11-RenSeq equivalence/mapping file.
      gene2=`awk -v trn="$gene" '$2 ~ trn {print $1}' bash-output-files/6909_RenSeq-TAIR_equiv.txt | awk -F\| '{print $2}'`; 
    else
      gene2="$gene"; #All other non-6909 accessions are OK as is, but we need same variable name
    fi;

    ngene=`echo "$line" | wc -l`; 
    tig=`awk -v sp="$acc" -v trn="$gene2" '$9 ~ sp && $9 ~ trn {print $1}' bash-input-files/gff/"$acc".gff | sort -u`; #contig
    gcontig=`awk -F'[;=\t]' -v crom="$tig" '$1 == crom && $3 == "mRNA" {print $10}' bash-input-files/gff/"$acc".gff | sed 's/ID=//g' | sort -u | awk -v ORS=, -v sp=$acc -v trn=$gene2 '{if ($1 !~ sp || $1 !~ trn) {print }}' | sed 's/,$/\n/g'`; #other genes in same contig, excluding the NLR from the OG
    ngcontig=`echo "$gcontig" | sed 's/,/\n/g' | sort -u | wc -l`;

    if [ -n "$gcontig" ]; #if there are other genes in same contig, process NLRs and non-NLRs
    then
      #is any of those genes an NLR?
      gnlrs=$(echo "$gcontig" | sed 's/,/\n/g' | while read gen; 
		do 
		  acc2=`echo "$gen" | awk -F\| '{print $1}'`; 
		  gene3=`echo "$gen" | awk -F\| '{print $2}'`; 
		  if [ "$acc2" == "6909" ]; 
		  then 
		    gene4=`awk -v trn="$gene3" '$1 ~ trn {print $2}' bash-output-files/6909_RenSeq-TAIR_equiv.txt | awk -F\| '{print $2}'`; 
		  else 
		    gene4="$gene3"; 
		  fi; 
		  gen2=`echo "$acc|$gene4"`; 
		  awk -v trn="$gen2" '$1 == trn {print $1}' "$outnlrgns"; 
		done | awk -v ORS=, '{print }' | sed 's/,$/\n/g' );
      ngnlrs=`echo "$gnlrs" | sed 's/,/\n/g' | sort -u | wc -l`;
      #is any of those NLRs in an OG, which?
      gogs=$(echo "$gcontig" | sed 's/,/\n/g' | while read gen; 
		do 
		  acc2=`echo "$gen" | awk -F\| '{print $1}'`; 
		  gene3=`echo "$gen" | awk -F\| '{print $2}'`; 
		  if [ "$acc2" == "6909" ]; 
		  then 
		    gene4=`awk -v trn="$gene3" '$1 ~ trn {print $2}' bash-output-files/6909_RenSeq-TAIR_equiv.txt | awk -F\| '{print $2}'`; 
		  else 
		    gene4="$gene3"; 
		  fi; 
		  gen2=`echo "$acc|$gene4"`; 

		  awk -v trn="$gen2" '$1 == trn {print FILENAME}' NLR-OGs/*.group | awk -F'[/: ]' '{print $2}' | sed 's/.group//g';
#		  grep "$gen2" NLR-OGs/*.group | awk -F'[/.group ]' '{print $10}'; Issue with dots in refined-ogs. use awk instead
		done | awk -v ORS=, '{print }' | sed 's/,$/\n/g'); 
      ngogs=`echo "$gogs" | sed 's/,/\n/g' | sort -u | wc -l`;
      #what if no gene is an NLR? Assign zero value variables
      if [ "$ngnlrs" -lt 1 ];
      then
	gnlrs="NA";
	ngnlrs=0;
        gogs="NA";
	ngogs=0;
      fi; 

      #is any of those genes an non-NLR?
      nongnlrs=$(echo "$gcontig" | sed 's/,/\n/g' | while read gen; 
		do 
		  acc2=`echo "$gen" | awk -F\| '{print $1}'`; 
		  gene3=`echo "$gen" | awk -F\| '{print $2}'`; 
		  if [ "$acc2" == "6909" ]; 
		  then 
		    gene4=`awk -v trn="$gene3" '$1 ~ trn {print $2}' bash-output-files/6909_RenSeq-TAIR_equiv.txt | awk -F\| '{print $2}'`; 
		  else gene4="$gene3"; 
		  fi; 
		  gen2=`echo "$acc|$gene4"`; 
		  awk -v trn="$gen2" '$1 == trn {print $1}' bash-output-files/non_nlr_genes.txt; 
		done | awk -v ORS=, '{print }' | sed 's/,$/\n/g'); 
      nnongnlrs=`echo "$nongnlrs" | sed 's/,/\n/g' | sort -u | wc -l`;
      #is any of those non-NLR genes in an non-NLR_OG, which?
      nongogs=$(echo "$gcontig" | sed 's/,/\n/g' | while read gen; 
		do 
		  acc2=`echo "$gen" | awk -F\| '{print $1}'`; 
		  gene3=`echo "$gen" | awk -F\| '{print $2}'`; 
		  if [ "$acc2" == "6909" ]; 
		  then 
		    gene4=`awk -v trn="$gene3" '$1 ~ trn {print $2}' bash-output-files/6909_RenSeq-TAIR_equiv.txt | awk -F\| '{print $2}'`; 
		  else 
		    gene4="$gene3"; 
		  fi; 
		  gen2=`echo "$acc|$gene4"`; 

		  awk -v trn="$gen2" '$1 == trn {print FILENAME}' nonNLR-OGs/*.group | awk -F'[/: ]' '{print $2}' | sed 's/.group//g';

#		  grep "$gen2" nonNLR-OGs/*.group | awk -F'[/. ]' '{print $10}'; in non-nlrs no prob, there are no dots in names
		done | awk -v ORS=, '{print }' | sed 's/,$/\n/g'); 
      nnongogs=`echo "$nongogs" | sed 's/,/\n/g' | sort -u | wc -l`;
      #what if no gene is a non-NLR? Assign zero value variables
      if [ "$nnongnlrs" -lt 1 ];
      then
	nongnlrs="NA";
	nnongnlrs=0;
        nongogs="NA";
	nnongogs=0;
      fi; 

    else	# if there are NOT other genes in the contig
      gcontig="NA";
      ngcontig=0;
      gnlrs="NA";
      ngnlrs=0;
      gogs="NA";
      ngogs=0;
      nongnlrs="NA";
      nnongnlrs=0;
      nongogs="NA";
      nnongogs=0;
    fi; 
    printf "$og\t$line\t$ngene\t$acc\t$tig\t$gcontig\t$ngcontig\t$gnlrs\t$ngnlrs\t$gogs\t$ngogs\t$nongnlrs\t$nnongnlrs\t$nongogs\t$nnongogs\n" >> bash-output-files/og-contig-files/same-contig-ogs/"$og".tsv; 
  done;
done;
printf " DONE\n";

#Produce network
printf "Producing Main Network ...........................................................";
for file in bash-output-files/og-contig-files/same-contig-ogs/*.tsv; 
do 
  atg=`awk -F'\t' '$2 ~ /^6909/ {print $2}' "$file" | awk -F\| '{print $2}' | grep -c '^AT'`;
  awk -F'\t' 'NR>1 {if ($10 != "" && $10 != "NA" && $14 != "" && $14 != "NA") {print }}' "$file" | while read line; 
  do 
    acc=`echo "$line" | awk -F'\t' '{print $4}'`; 
    og=`echo "$line" | awk -F'\t' '{print $1}'`; 
    ogsize=`wc -l NLR-OGs/"$og".group | awk '{print $1}'`;

    nlrog=$(echo "$line" | awk -F'\t' '{print $10}' | sed 's/,/\n/g' | while read nlr; 
    do 
      nlrogsize=`wc -l NLR-OGs/"$nlr".group | awk '{print $1}'`;
      nlratg=`awk -F'\t' '$1 ~ /^6909/ {print $1}' NLR-OGs/"$nlr".group | awk -F\| '{print $2}' | grep -c '^AT'`;
      printf "$acc\tnlr-$og\tnlr-$nlr\tNLR\tNLR\t$atg\t$nlratg\t$ogsize\t$nlrogsize\n"; 
    done); 

    nonnlrog=$(echo "$line" | awk -F'\t' '{print $14}' | sed 's/,/\n/g' | while read nonnlr; 
    do 
      nonnlrogsize=`wc -l nonNLR-OGs/"$nonnlr".group | awk '{print $1}'`;
      nonnlratg=`awk -F'\t' '$1 ~ /^6909/ {print $1}' nonNLR-OGs/"$nonnlr".group | awk -F\| '{print $2}' | grep -c '^AT'`;
      printf "$acc\tnlr-$og\t$nonnlr\tNLR\tnonNLR\t$atg\t$nonnlratg\t$ogsize\t$nonnlrogsize\n"; 
    done); 

    echo "$nlrog"; 
    echo "$nonnlrog"; 
  done; 
done | sort -k2,2 -k3,3 -k1,1n > bash-output-files/og-contig-files/network/all.out
printf " DONE\n";

printf "Compressing intermediate .tsv files ..............................................";
tar -zcf bash-output-files/og-contig-files/same-contig-ogs/same-contig-in-ogs-tsv.tar.gz bash-output-files/og-contig-files/same-contig-ogs/*.tsv;
rm bash-output-files/og-contig-files/same-contig-ogs/*.tsv;
printf " DONE\n";


####Section below produces two main outputs:
####1. Co-occurrence network files that can be imported into Cytoscape to visualize co-occurrence given thresholds. 
####2. Anchoring efficiency. Ratio of successfully anchored non-refrence NLR-OGs that were anchored to reference NLR and non-NLR OGs. Ratio is calculated based on the number of observations, or in other words, the number of accessions in which a co-occurrence of non-reference NLR-OG was observed with the same reference NLR-OG, or nonNLR-OG. Col-0 and Col-0/Ler were used as reference. For this experiment we HAD TO work with the RenSeq Col-0 data. TAIR and RenSeq Col-0 were obtained using Reciprocal best blast hits.

#Generate Network files from part1 output:
printf "Applying thresholds to co-ocurrence networks .....................................";
for i in {1..42}; do
printf "Source\tTarget\tSource_color\tTarget_color\tSource_shape\tTarget_shape\tEdge_width1\tEdge_width2\tSource_size\tTarget_size\n" > "$outnets/network_gt_$i.out";
awk -F'\t' -v OFS='\t' '{print $2,$3,$4,$5,$6,$7,$8,$9}' "$outnets/all.out" | uniq -c | sort -k1,1 -k2,2 | awk -v OFS='\t' -v i=$i '$1 > i {print $2,$3,$4,$5,$6,$7,$1,($1/65),$8,$9}' >> "$outnets/network_gt_$i.out"; done
printf " DONE\n"

#Generate summary table
##Anchoring efficiency - How many Non-Col-0 NLR OGs are we able to successfully anchor to a given Col-0 genomic position
printf "Calculating Anchoring efficiencies and reporting anchored/placed OGs .............";
printf "Accession_Threshold\tAnchored_NLR-OGs\tAnchored_nonNLR-OGs\tnonCol-0/Ler_OGs_above_threshold\tAnchoring_efficiency\tAnchoring_Col-0/Ler_NLR-OG\tAnchoring_to_Col-0/Ler_nonNLR-OG\tAnchored_NLR-OGs\n" > bash-output-files/Anchoring-efficiency_Col-0_Ler.tsv; 
printf "Accession_Threshold\tAnchored_NLR-OGs\tAnchored_nonNLR-OGs\tnonCol-0_OGs_above_threshold\tAnchoring_efficiency\tAnchoring_Col-0_NLR-OG\tAnchoring_to_Col-0_nonNLR-OG\tAnchored_NLR-OGs\n" > bash-output-files/Anchoring-efficiency_Col-0.tsv; 
for i in {1..42}; 
do 
  l=`echo "$i+1" | bc`;

  sizenlr1=$(awk -v ORS=, -v OFS=, -F'\t' '{if (($5 == "1" && $6 == "0" && $4 == "NLR") || ($5 == "0" && $6 == "1" && $3 == "NLR")) {print $1,$2}}' "$outnets/network_gt_$i.out" | sed -e 's/,$/\n/g' -e 's/,/\n/g' | sort -u | awk '$1 ~ /^nlr-/ {print }' | sed 's/nlr-//g' | while read line; do atg=`grep -c '^6909' NLR-OGs/"$line".group`; ogsize=`cat NLR-OGs/"$line".group | wc -l`; printf "$line\t$atg\t$ogsize\n"; done | awk '$2 == "0" {print "nlr-"$1,$2,$3}' | wc -l);   
  sizenlr2=$(awk -v ORS=, -v OFS=, -F'\t' '{if (($5 == "1" && $6 == "0" && $4 == "NLR") || ($5 == "0" && $6 == "1" && $3 == "NLR")) {print $1,$2}}' "$outnets/network_gt_$i.out" | sed -e 's/,$/\n/g' -e 's/,/\n/g' | sort -u | awk '$1 ~ /^nlr-/ {print }' | sed 's/nlr-//g' | while read line; do atg=`grep -c '^6909\|^7213' NLR-OGs/"$line".group`; ogsize=`cat NLR-OGs/"$line".group | wc -l`; printf "$line\t$atg\t$ogsize\n"; done | awk '$2 == "0" {print "nlr-"$1,$2,$3}' | wc -l); 
#sizenlr=$(awk -v ORS=, -v OFS=, -F'\t' '{if (($5 == "1" && $6 == "0") || ($5 == "0" && $6 == "1")) {print $1,$2}}' "$outnets/network_gt_$i.out" | sed -e 's/,$/\n/g' -e 's/,/\n/g' | sort -u | awk '$1 ~ /^NLR_/ {print }' | sed 's/NLR_//g' | while read line; do atg=`grep -c '^6909\|^7213' NLR-OGs/"$line".group`; ogsize=`cat NLR-OGs/"$line".group | wc -l`; printf "$line\t$atg\t$ogsize\n"; done | awk '$2 == "0" {print "NLR_"$1,$2,$3}' | wc -l);

  ids1=$(awk -v ORS=, -v OFS=, -F'\t' '{if (($5 == "1" && $6 == "0" && $4 == "NLR") || ($5 == "0" && $6 == "1" && $3 == "NLR")) {print $1,$2}}' "$outnets/network_gt_$i.out" | sed -e 's/,$/\n/g' -e 's/,/\n/g' | sort -u | awk '$1 ~ /^nlr-/ {print }' | sed 's/nlr-//g' | while read line; do atg=`grep -c '^6909' NLR-OGs/"$line".group`; ogsize=`cat NLR-OGs/"$line".group | wc -l`; printf "$line\t$atg\t$ogsize\n"; done | awk '$2 == "0" {print "nlr-"$1,$2,$3}' | sort -k3,3rn | awk -v ORS=, '{print $1}' | sed 's/,$/\n/'); 
  ids2=$(awk -v ORS=, -v OFS=, -F'\t' '{if (($5 == "1" && $6 == "0" && $4 == "NLR") || ($5 == "0" && $6 == "1" && $3 == "NLR")) {print $1,$2}}' "$outnets/network_gt_$i.out" | sed -e 's/,$/\n/g' -e 's/,/\n/g' | sort -u | awk '$1 ~ /^nlr-/ {print }' | sed 's/nlr-//g' | while read line; do atg=`grep -c '^6909\|^7213' NLR-OGs/"$line".group`; ogsize=`cat NLR-OGs/"$line".group | wc -l`; printf "$line\t$atg\t$ogsize\n"; done | awk '$2 == "0" {print "nlr-"$1,$2,$3}' | sort -k3,3rn | awk -v ORS=, '{print $1}' | sed 's/,$/\n/'); 

  sizenonnlr1=$(awk -v ORS=, -v OFS=, -F'\t' '{if (($5 == "1" && $6 == "0" && $4 == "nonNLR") || ($5 == "0" && $6 == "1" && $3 == "nonNLR")) {print $1,$2}}' "$outnets/network_gt_$i.out" | sed -e 's/,$/\n/g' -e 's/,/\n/g' | sort -u | awk '$1 ~ /^nonnlr-/ {print }' | while read line; do atg=`grep -c '^6909' nonNLR-OGs/"$line".group`; ogsize=`cat nonNLR-OGs/"$line".group | wc -l`; printf "$line\t$atg\t$ogsize\n"; done | awk '$2 == "0" {print "nonnlr-"$1,$2,$3}' | wc -l);
  sizenonnlr2=$(awk -v ORS=, -v OFS=, -F'\t' '{if (($5 == "1" && $6 == "0" && $4 == "nonNLR") || ($5 == "0" && $6 == "1" && $3 == "nonNLR")) {print $1,$2}}' "$outnets/network_gt_$i.out" | sed -e 's/,$/\n/g' -e 's/,/\n/g' | sort -u | awk '$1 ~ /^nonnlr-/ {print }' | while read line; do atg=`grep -c '^6909\|^7213' nonNLR-OGs/"$line".group`; ogsize=`cat nonNLR-OGs/"$line".group | wc -l`; printf "$line\t$atg\t$ogsize\n"; done | awk '$2 == "0" {print "nonnlr-"$1,$2,$3}' | wc -l); 
#sizenonnlr=$(awk -v ORS=, -v OFS=, -F'\t' '{if (($5 == "1" && $6 == "0") || ($5 == "0" && $6 == "1")) {print $1,$2}}' "$outnets/network_gt_$i.out" | sed -e 's/,$/\n/g' -e 's/,/\n/g' | sort -u | awk '$1 ~ /^nonNLR/ {print }' | sed 's/nonNLR_//g' | while read line; do atg=`grep -c '^6909\|^7213' nonNLR-OGs/"$line".group`; ogsize=`cat nonNLR-OGs/"$line".group | wc -l`; printf "$line\t$atg\t$ogsize\n"; done | awk '$2 == "0" {print "nonNLR_"$1,$2,$3}' | wc -l); 

  anchtonlr1=$(awk -v ORS=, -v OFS=, -F'\t' '{if (($5 == "1" && $6 == "0" && $3 == "NLR") || ($5 == "0" && $6 == "1" && $4 == "NLR")) {print $1,$2}}' "$outnets/network_gt_$i.out" | sed -e 's/,$/\n/g' -e 's/,/\n/g' | sort -u | awk '$1 ~ /^nlr-/ {print }' | sed 's/nlr-//g' | while read line; do atg=`grep -c '^6909' NLR-OGs/"$line".group`; ogsize=`cat NLR-OGs/"$line".group | wc -l`; printf "$line\t$atg\t$ogsize\n"; done | awk '$2 >= 1 {print "nlr-"$1,$2,$3}' | wc -l);
  anchtonlr2=$(awk -v ORS=, -v OFS=, -F'\t' '{if (($5 == "1" && $6 == "0" && $3 == "NLR") || ($5 == "0" && $6 == "1" && $4 == "NLR")) {print $1,$2}}' "$outnets/network_gt_$i.out" | sed -e 's/,$/\n/g' -e 's/,/\n/g' | sort -u | awk '$1 ~ /^nlr-/ {print }' | sed 's/nlr-//g' | while read line; do atg=`grep -c '^6909\|^7213' NLR-OGs/"$line".group`; ogsize=`cat NLR-OGs/"$line".group | wc -l`; printf "$line\t$atg\t$ogsize\n"; done | awk '$2 >= 1 {print "nlr-"$1,$2,$3}' | wc -l);
#anchtonlr=$(awk -v ORS=, -v OFS=, -F'\t' '{if (($5 == "1" && $6 == "0") || ($5 == "0" && $6 == "1")) {print $1,$2}}' "$outnets/network_gt_$i.out" | sed -e 's/,$/\n/g' -e 's/,/\n/g' | sort -u | awk '$1 ~ /^NLR_/ {print }' | sed 's/NLR_//g' | while read line; do atg=`grep -c '^6909\|^7213' NLR-OGs/"$line".group`; ogsize=`cat NLR-OGs/"$line".group | wc -l`; printf "$line\t$atg\t$ogsize\n"; done | awk '$2 >= 1 {print "NLR_"$1,$2,$3}' | wc -l);

  anchtononnlr1=$(awk -v ORS=, -v OFS=, -F'\t' '{if (($5 == "1" && $6 == "0" && $3 == "nonNLR") || ($5 == "0" && $6 == "1" && $4 == "nonNLR")) {print $1,$2}}' "$outnets/network_gt_$i.out" | sed -e 's/,$/\n/g' -e 's/,/\n/g' | sort -u | awk '$1 ~ /^nonnlr-/ {print }' | while read line; do atg=`grep -c '^6909' nonNLR-OGs/"$line".group`; ogsize=`cat nonNLR-OGs/"$line".group | wc -l`; printf "$line\t$atg\t$ogsize\n"; done | awk '$2 >= 1 {print "nonnlr-"$1,$2,$3}' | wc -l);
  anchtononnlr2=$(awk -v ORS=, -v OFS=, -F'\t' '{if (($5 == "1" && $6 == "0" && $3 == "nonNLR") || ($5 == "0" && $6 == "1" && $4 == "nonNLR")) {print $1,$2}}' "$outnets/network_gt_$i.out" | sed -e 's/,$/\n/g' -e 's/,/\n/g' | sort -u | awk '$1 ~ /^nonnlr-/ {print }' | while read line; do atg=`grep -c '^6909\|^7213' nonNLR-OGs/"$line".group`; ogsize=`cat nonNLR-OGs/"$line".group | wc -l`; printf "$line\t$atg\t$ogsize\n"; done | awk '$2 >= 1 {print "nonnlr-"$1,$2,$3}' | wc -l);
#anchtononnlr=$(awk -v ORS=, -v OFS=, -F'\t' '{if (($5 == "1" && $6 == "0") || ($5 == "0" && $6 == "1")) {print $1,$2}}' "$outnets/network_gt_$i.out" | sed -e 's/,$/\n/g' -e 's/,/\n/g' | sort -u | awk '$1 ~ /^nonNLR/ {print }' | sed 's/nonNLR_//g' | while read line; do atg=`grep -c '^6909\|^7213' nonNLR-OGs/"$line".group`; ogsize=`cat nonNLR-OGs/"$line".group | wc -l`; printf "$line\t$atg\t$ogsize\n"; done | awk '$2 >= 1 {print "nonNLR_"$1,$2,$3}' | wc -l);

  numnocolog1=$(for file in NLR-OGs/*.group; do col=`grep -c '^6909' "$file"`; size=`cat "$file" | wc -l`; echo "$col $size" | awk -v i=$i '$1 == "0" && $2 > i {print }'; done | wc -l);
  numnocolog2=$(for file in NLR-OGs/*.group; do col=`grep -c '^6909\|^7213' "$file"`; size=`cat "$file" | wc -l`; echo "$col $size" | awk -v i=$i '$1 == "0" && $2 > i {print }'; done | wc -l);
#  sizecologs=$();
  printf "$l\t$sizenlr1\t$sizenonnlr1\t$numnocolog1\t$anchtonlr1\t$anchtononnlr1\t$ids1\n" | awk -F'\t' -v OFS='\t' '{print $1,$2,$3,$4,($2/$4*100),$5,$6,$7}' >> bash-output-files/Anchoring-efficiency_Col-0.tsv;
  printf "$l\t$sizenlr2\t$sizenonnlr2\t$numnocolog2\t$anchtonlr2\t$anchtononnlr2\t$ids2\n" | awk -F'\t' -v OFS='\t' '{print $1,$2,$3,$4,($2/$4*100),$5,$6,$7}' >> bash-output-files/Anchoring-efficiency_Col-0_Ler.tsv; 
done
printf " DONE\n"


#Below, we use gff-og integration to parse same contig OGs. Instead of reporting 1:1 og:og contig co-occurrences, mapping files are build from gff
#mapping file to modify nlr mRNA
printf "Almost done, quantifying co-ocurrences\n";
printf "Creating gff mRNA mapping file from NLR OGs ......................................";
for file in NLR-OGs/*.group; 
do 
  og2=$(basename $file); og2=${og2/.group/}; og=`echo "$og2" | sed -e 's/\./\\\\\\\./'`; 
  ogname=`awk -v ORS=\| -F'[ \t|]' '$1 ~ /^6909/ {print $2}' "$file" | sed 's/|$/\n/g'`; 
  ogsize=`cat "$file" | wc -l`;
  statu=`gawk -F'\t' -v og=$og '$1 ~ "^"og"$" {print $3}' bash-input-files/nlrome.refined.groups`;
  use=`gawk -F'\t' -v og=$og '$1 ~ "^"og"$" {print $4}' bash-input-files/nlrome.refined.groups`;
  if [[ -z "$ogname" ]]; 
  then ogname=NA; 
  else name2=`gawk -F'\t' -v ogname="$ogname" '$1 ~ "^"ogname"$" {print $2}' bash-input-files/functional_Col-0-NLRs.txt`; 
       if [[ -n "$name2" ]]; 
       then ogname=`echo "$ogname"_"$name2"`; 
       fi; 
  fi; 
  cat "$file" | while read line; 
  do 
    acc=`echo "$line" | awk -F\| '{print $1}'`; 
    tra2=`echo "$line" | awk -F\| '{print $2}'`;
    if [ "$acc" == "6909" ]; 
    then 
      tra=`gawk -F'[ |]' -v a=$acc -v t=$tra2 -v l=$line '$3 ~ "^"a"$" && $4 ~ "^"t"$" {print $2}' bash-output-files/6909_RenSeq-TAIR_equiv.txt`; 
      if [ -z "$tra" ]; 
      then 
        tra=$tra2;  
      fi; 
    else 
      tra=$tra2;  
    fi;
  
    awk -F'[;=\t]' -v OFS='\t' -v og="$og2" -v ogname="$ogname" -v ogsize="$ogsize" -v st="$statu" -v use="$use" -v t="$tra" -v a="$acc" '$3 == "mRNA" && $10 ~ a && $10 ~ t {print a,$10,$1,$4,$5,"OG="og,"OGname="ogname,"OGsize="ogsize,"Status="st,"Use="use}' bash-input-files/gff/"$acc".gff; 
  done; 
done > bash-output-files/og-contig-files/mapping-mRNA-NLRs-gff.txt
printf " DONE\n";

#mapping file to modify nonNLRs mRNA
printf "Creating gff mRNA mapping file from non-NLR OGs ..................................";
for file in nonNLR-OGs/*.group; 
do 
  og2=$(basename $file); og2=${og2/.group/}; og=`echo "$og2" | sed -e 's/\./\\\\\\\./'`; 
  ogname=`awk -v ORS=\| -F'[ \t|]' '$1 ~ /^6909/ {print $2}' "$file" | sed 's/|$/\n/g'`; 
  ogsize=`cat "$file" | wc -l`;
  statu="nonnlr.orthogroup";
  use="0";
  if [[ -z "$ogname" ]]; 
  then ogname=NA; 
  fi; 
  cat "$file" | while read line; 
  do 
    acc=`echo "$line" | awk -F\| '{print $1}'`; 
    tra2=`echo "$line" | awk -F\| '{print $2}'`;
    if [ "$acc" == "6909" ]; 
    then 
      tra=`gawk -F'[ |]' -v a=$acc -v t=$tra2 -v l=$line '$3 ~ "^"a"$" && $4 ~ "^"t"$" {print $2}' bash-output-files/6909_RenSeq-TAIR_equiv.txt`; 
      if [ -z "$tra" ]; 
      then 
        tra=`echo "$line" | awk -F\| '{print $2}'`;  
      fi; 
    else 
      tra=`echo "$line" | awk -F\| '{print $2}'`;  
    fi;

#   awk -F'[;=\t]' -v OFS='\t' -v og="$og2" -v ogname="$ogname" -v ogsize="$ogsize" -v st="$statu" -v use="$use" -v t="$tra" -v a="$acc" '$3 == "mRNA" && $10 ~ a && $10 ~ t {print a,$10,$1,$4,$5,"OG=nonNLR_"og,"OGname="ogname,"OGsize="ogsize,"Status="st,"Use="use}' bash-input-files/gff/"$acc".gff; 
   awk -F'[;=\t]' -v OFS='\t' -v og="$og2" -v ogname="$ogname" -v ogsize="$ogsize" -v st="$statu" -v use="$use" -v t="$tra" -v a="$acc" '$3 == "mRNA" && $10 ~ a && $10 ~ t {print a,$10,$1,$4,$5,"OG="og,"OGname="ogname,"OGsize="ogsize,"Status="st,"Use="use}' bash-input-files/gff/"$acc".gff; 
  done; 
done > bash-output-files/og-contig-files/mapping-mRNA-nonNLRs-gff.txt
printf " DONE\n";

#Merge NLR and Non-NLR mapping files
printf "Concatenating NLR and nonNLR mapping files .......................................";
cat bash-output-files/og-contig-files/mapping-mRNA-{nonNLRs,NLRs}-gff.txt | sort -k1,1n -k3,3 -k2,2 > bash-output-files/og-contig-files/mapping-mRNA-gff_cat.txt
printf " DONE\n";

#Generating per OG linkages using the gff mapping file obtained above
printf "Generating contig-OG co-occurrences txt files ....................................";
awk -F'[\t=]' -v OFS=\t '{print $7}' bash-output-files/og-contig-files/mapping-mRNA-gff_cat.txt | sort -u | while read og2; 
do 
  og=`echo "$og2" | sed -e 's/\./\\\\\\\./'`; 
  awk -F'[\t=]' -v OFS=\t -v og=$og '$7 ~ "^"og"$" {print }' bash-output-files/og-contig-files/mapping-mRNA-gff_cat.txt | while read line; 
  do 
    acc=`echo "$line" | awk -F'\t' '{print $1}'`; 
    tig=`echo "$line" | awk -F'\t' '{print $3}'`; 
    gawk -F'\t' -v OFS=\t -v acc="$acc" -v tig="$tig" '$1 ~ "^"acc"$" && $3 ~ "^"tig"$" {print }' bash-output-files/og-contig-files/mapping-mRNA-gff_cat.txt; 
  done > "$output2/$og2.txt"; 
done;

printf " DONE\n";


#Print contiguity / co-occurrence matrix with transcript names
printf "Generating OG-co-occurrence matrices .............................................";
for mapping in "$output2"/*.txt; 
do 
  fname=$(basename $mapping); fname=${fname/.txt/}; 
  awk '{print $1}' bash-input-files/accession_metadata.tsv | while read line; 
  do 
    printf "x$line\t"; 
  done | sed 's/\t$/\n/' > "$output2/matrix_$fname.tsv"; 

  awk -F'[\t=]' '{print $7,$9}' "$mapping" | sort -u | while read og2 ogname; 
  do 
    og=`echo "$og2" | sed -e 's/\./\\\\\\\./'`; 
    a108=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "108" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a1925=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "1925" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a5784=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "5784" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a5993=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "5993" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a6899=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "6899" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a6906=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "6906" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a6909=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "6909" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a6924=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "6924" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a6939=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "6939" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a6974=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "6974" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a6981=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "6981" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a7058=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "7058" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a7063=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "7063" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a7067=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "7067" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a7111=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "7111" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a7167=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "7167" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a7186=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "7186" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a7213=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "7213" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a7273=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "7273" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a7288=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "7288" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a7308=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "7308" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a7322=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "7322" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a7328=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "7328" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a7373=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "7373" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a7396=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "7396" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a7413=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "7413" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a7415=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "7415" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a7416=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "7416" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a7417=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "7417" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a9100=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "9100" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a9134=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "9134" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a9332=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "9332" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a9518=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "9518" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a9533=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "9533" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a9536=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "9536" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a9537=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "9537" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a9542=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "9542" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a9543=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "9543" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a9545=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "9545" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a9549=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "9549" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a9550=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "9550" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a9554=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "9554" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a9557=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "9557" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a9580=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "9580" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a9583=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "9583" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a9597=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "9597" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a9600=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "9600" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a9610=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "9610" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a9654=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "9654" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a9658=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "9658" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a9669=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "9669" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a9721=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "9721" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a9762=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "9762" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a9764=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "9764" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a9784=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "9784" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a9792=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "9792" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a9837=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "9837" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a9869=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "9869" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a9871=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "9871" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a9879=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "9879" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a9887=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "9887" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a9911=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "9911" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a9944=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "9944" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a9947=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "9947" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    a10015=`gawk -F'[\t=]' -v ORS=, -v og=$og '{ if ( $1 == "10015" && $7 ~ "^"og"$" ) {print $2}}' "$mapping" | sed 's/,$/\n/'`;  
    printf "$og2"_"$ogname\t$a108\t$a1925\t$a5784\t$a5993\t$a6899\t$a6906\t$a6909\t$a6924\t$a6939\t$a6974\t$a6981\t$a7058\t$a7063\t$a7067\t$a7111\t$a7167\t$a7186\t$a7213\t$a7273\t$a7288\t$a7308\t$a7322\t$a7328\t$a7373\t$a7396\t$a7413\t$a7415\t$a7416\t$a7417\t$a9100\t$a9134\t$a9332\t$a9518\t$a9533\t$a9536\t$a9537\t$a9542\t$a9543\t$a9545\t$a9549\t$a9550\t$a9554\t$a9557\t$a9580\t$a9583\t$a9597\t$a9600\t$a9610\t$a9654\t$a9658\t$a9669\t$a9721\t$a9762\t$a9764\t$a9784\t$a9792\t$a9837\t$a9869\t$a9871\t$a9879\t$a9887\t$a9911\t$a9944\t$a9947\t$a10015\n" | sort -k8,8 -k12,12 -k44,44 -k53,53 -k49,49 -k7,7 -k48,48 -k5,5 | awk 'BEGIN { FS = OFS = "\t" } { for(i=1; i<=NF; i++) if($i ~ /^ *$/) $i = 0 }; 1' | sed -e 's/_NA//' >> "$output2/matrix_$fname.tsv";  
  done; 
done;
printf " DONE\n";

printf "Compressing contig-OG co-occurrences txt files ...................................";
tar -zcf "$output2"/contig-og-txt.tar.gz "$output2"/*.txt;
rm "$output2"/*.txt;
printf " DONE\n";


for matrix in bash-output-files/og-contig-files/og-mappings/matrix_*.tsv; 
do 
  og=$(basename "$matrix"); og=${og/matrix_/}; og=${og/.tsv/}; 
  cat "$matrix" | awk 'BEGIN { FS = OFS = "\t" } { for(i=1; i<=NF; i++) if($i ~ /^.*\|.*$/) $i = 1 }; 1' > bash-output-files/og-contig-files/og-mappings/bin_matrix_"$og".tsv; 
  awk -f bash-input-files/transpose.awk "$matrix" > bash-output-files/og-contig-files/og-mappings/trnsp_matrix_"$og".tsv; 
  cat bash-output-files/og-contig-files/og-mappings/trnsp_matrix_"$og".tsv | awk 'BEGIN { FS = OFS = "\t" } { for(i=1; i<=NF; i++) if($i ~ /^.*\|.*$/) $i = 1 }; 1' > bash-output-files/og-contig-files/og-mappings/bin_trnsp_matrix_"$og".tsv; 
done



printf "The following steps require manual input from Cytoscape. Generates matrices reporting the co-occurrences to each OG analyzed. Matrices can be imported to Excel/Calc. We used this approach in a preliminar analysis, but the tables/matrices produced are not shown in the manuscript.\n. This STEP can be ommited using <CTRL+C>\n\n"
printf "OPEN $outnets/network_gt_{1..12}.out in Cytoscape\nand Export EACH cluster in EACH network to: bash-output-files/og-contig-files/network/OG_Contiguity_more_than_{1..12}_contig_linkage_evidences/cluster*.tsv\n\n";
printf "Make sure subnetwork tsv's are ready in bash-output-files/og-contig-files/network/OG_Contiguity_more_than_{1..12}_contig_linkage_evidences/cluster*.tsv\n\n\n"
read -p "All required files for Figures were created. Press <ENTER> to continue, or <CTRL+C> to exit"

for file in bash-output-files/og-contig-files/network/OG_Contiguity_more_than_1_contig_linkage_evidences/cluster*.tsv;
do
fname=$(basename $file); fname=${fname/.tsv/};
printf "OG\tx108\tx1925\tx5784\tx5993\tx6899\tx6906\tx6909\tx6924\tx6939\tx6974\tx6981\tx7058\tx7063\tx7067\tx7111\tx7167\tx7186\tx7213\tx7273\tx7288\tx7308\tx7322\tx7328\tx7373\tx7396\tx7413\tx7415\tx7416\tx7417\tx9100\tx9134\tx9332\tx9518\tx9533\tx9536\tx9537\tx9542\tx9543\tx9545\tx9549\tx9550\tx9554\tx9557\tx9580\tx9583\tx9597\tx9600\tx9610\tx9654\tx9658\tx9669\tx9721\tx9762\tx9764\tx9784\tx9792\tx9837\tx9869\tx9871\tx9879\tx9887\tx9911\tx9944\tx9947\tx10015\n" > bash-output-files/og-contig-files/network/OG_Contiguity_more_than_1_contig_linkage_evidences/clusterorderedOGs_"$fname".out;
awk -F'\t' '{print $1}' "$file" | sed '/^\s*$/d' | while read line; 
do 
  ogtype=`echo "$line" | awk -F_ '{print $1}'`; 
  ognumber=`echo "$line" | awk -F_ '{print $2}'`; 

  if [ "$ogtype" = "NLR" ]; 
  then
    acc108=`awk -v ORS=, '$1 ~ /^108/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc1925=`awk -v ORS=, '$1 ~ /^1925/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc5784=`awk -v ORS=, '$1 ~ /^5784/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc5993=`awk -v ORS=, '$1 ~ /^5993/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc6899=`awk -v ORS=, '$1 ~ /^6899/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc6906=`awk -v ORS=, '$1 ~ /^6906/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc6909=`awk -v ORS=, '$1 ~ /^6909/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc6924=`awk -v ORS=, '$1 ~ /^6924/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc6939=`awk -v ORS=, '$1 ~ /^6939/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc6974=`awk -v ORS=, '$1 ~ /^6974/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc6981=`awk -v ORS=, '$1 ~ /^6981/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc7058=`awk -v ORS=, '$1 ~ /^7058/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc7063=`awk -v ORS=, '$1 ~ /^7063/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc7067=`awk -v ORS=, '$1 ~ /^7067/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc7111=`awk -v ORS=, '$1 ~ /^7111/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc7167=`awk -v ORS=, '$1 ~ /^7167/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc7186=`awk -v ORS=, '$1 ~ /^7186/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc7213=`awk -v ORS=, '$1 ~ /^7213/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc7273=`awk -v ORS=, '$1 ~ /^7273/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc7288=`awk -v ORS=, '$1 ~ /^7288/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc7308=`awk -v ORS=, '$1 ~ /^7308/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc7322=`awk -v ORS=, '$1 ~ /^7322/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc7328=`awk -v ORS=, '$1 ~ /^7328/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc7373=`awk -v ORS=, '$1 ~ /^7373/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc7396=`awk -v ORS=, '$1 ~ /^7396/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc7413=`awk -v ORS=, '$1 ~ /^7413/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc7415=`awk -v ORS=, '$1 ~ /^7415/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc7416=`awk -v ORS=, '$1 ~ /^7416/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc7417=`awk -v ORS=, '$1 ~ /^7417/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9100=`awk -v ORS=, '$1 ~ /^9100/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9134=`awk -v ORS=, '$1 ~ /^0134/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9332=`awk -v ORS=, '$1 ~ /^9332/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9518=`awk -v ORS=, '$1 ~ /^9518/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9533=`awk -v ORS=, '$1 ~ /^9533/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9536=`awk -v ORS=, '$1 ~ /^9536/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9537=`awk -v ORS=, '$1 ~ /^9537/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9542=`awk -v ORS=, '$1 ~ /^9542/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9543=`awk -v ORS=, '$1 ~ /^9543/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9545=`awk -v ORS=, '$1 ~ /^9545/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9549=`awk -v ORS=, '$1 ~ /^9549/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9550=`awk -v ORS=, '$1 ~ /^9550/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9554=`awk -v ORS=, '$1 ~ /^9554/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9557=`awk -v ORS=, '$1 ~ /^9557/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9580=`awk -v ORS=, '$1 ~ /^9580/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9583=`awk -v ORS=, '$1 ~ /^9583/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9597=`awk -v ORS=, '$1 ~ /^9597/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9600=`awk -v ORS=, '$1 ~ /^9600/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9610=`awk -v ORS=, '$1 ~ /^9610/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9654=`awk -v ORS=, '$1 ~ /^9654/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9658=`awk -v ORS=, '$1 ~ /^9658/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9669=`awk -v ORS=, '$1 ~ /^9669/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9721=`awk -v ORS=, '$1 ~ /^9721/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9762=`awk -v ORS=, '$1 ~ /^9762/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9764=`awk -v ORS=, '$1 ~ /^9764/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9784=`awk -v ORS=, '$1 ~ /^9784/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9792=`awk -v ORS=, '$1 ~ /^9792/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9837=`awk -v ORS=, '$1 ~ /^9837/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9869=`awk -v ORS=, '$1 ~ /^9869/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9871=`awk -v ORS=, '$1 ~ /^9871/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9879=`awk -v ORS=, '$1 ~ /^9879/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9887=`awk -v ORS=, '$1 ~ /^9887/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9911=`awk -v ORS=, '$1 ~ /^9911/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9944=`awk -v ORS=, '$1 ~ /^9944/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9947=`awk -v ORS=, '$1 ~ /^9947/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc10015=`awk -v ORS=, '$1 ~ /^10015/ {print $1}' NLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;

  else
    acc108=`awk -v ORS=, '$1 ~ /^108/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc1925=`awk -v ORS=, '$1 ~ /^1925/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc5784=`awk -v ORS=, '$1 ~ /^5784/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc5993=`awk -v ORS=, '$1 ~ /^5993/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc6899=`awk -v ORS=, '$1 ~ /^6899/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc6906=`awk -v ORS=, '$1 ~ /^6906/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc6909=`awk -v ORS=, '$1 ~ /^6909/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc6924=`awk -v ORS=, '$1 ~ /^6924/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc6939=`awk -v ORS=, '$1 ~ /^6939/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc6974=`awk -v ORS=, '$1 ~ /^6974/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc6981=`awk -v ORS=, '$1 ~ /^6981/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc7058=`awk -v ORS=, '$1 ~ /^7058/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc7063=`awk -v ORS=, '$1 ~ /^7063/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc7067=`awk -v ORS=, '$1 ~ /^7067/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc7111=`awk -v ORS=, '$1 ~ /^7111/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc7167=`awk -v ORS=, '$1 ~ /^7167/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc7186=`awk -v ORS=, '$1 ~ /^7186/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc7213=`awk -v ORS=, '$1 ~ /^7213/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc7273=`awk -v ORS=, '$1 ~ /^7273/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc7288=`awk -v ORS=, '$1 ~ /^7288/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc7308=`awk -v ORS=, '$1 ~ /^7308/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc7322=`awk -v ORS=, '$1 ~ /^7322/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc7328=`awk -v ORS=, '$1 ~ /^7328/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc7373=`awk -v ORS=, '$1 ~ /^7373/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc7396=`awk -v ORS=, '$1 ~ /^7396/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc7413=`awk -v ORS=, '$1 ~ /^7413/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc7415=`awk -v ORS=, '$1 ~ /^7415/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc7416=`awk -v ORS=, '$1 ~ /^7416/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc7417=`awk -v ORS=, '$1 ~ /^7417/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9100=`awk -v ORS=, '$1 ~ /^9100/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9134=`awk -v ORS=, '$1 ~ /^9134/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9332=`awk -v ORS=, '$1 ~ /^9332/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9518=`awk -v ORS=, '$1 ~ /^9518/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9533=`awk -v ORS=, '$1 ~ /^9533/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9536=`awk -v ORS=, '$1 ~ /^9536/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9537=`awk -v ORS=, '$1 ~ /^9537/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9542=`awk -v ORS=, '$1 ~ /^9542/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9543=`awk -v ORS=, '$1 ~ /^9543/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9545=`awk -v ORS=, '$1 ~ /^9545/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9549=`awk -v ORS=, '$1 ~ /^9549/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9550=`awk -v ORS=, '$1 ~ /^9550/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9554=`awk -v ORS=, '$1 ~ /^9554/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9557=`awk -v ORS=, '$1 ~ /^9557/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9580=`awk -v ORS=, '$1 ~ /^9580/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9583=`awk -v ORS=, '$1 ~ /^9583/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9597=`awk -v ORS=, '$1 ~ /^9597/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9600=`awk -v ORS=, '$1 ~ /^9600/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9610=`awk -v ORS=, '$1 ~ /^9610/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9654=`awk -v ORS=, '$1 ~ /^9654/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9658=`awk -v ORS=, '$1 ~ /^9658/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9669=`awk -v ORS=, '$1 ~ /^9669/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9721=`awk -v ORS=, '$1 ~ /^9721/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9762=`awk -v ORS=, '$1 ~ /^9762/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9764=`awk -v ORS=, '$1 ~ /^9764/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9784=`awk -v ORS=, '$1 ~ /^9784/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9792=`awk -v ORS=, '$1 ~ /^9792/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9837=`awk -v ORS=, '$1 ~ /^9837/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9869=`awk -v ORS=, '$1 ~ /^9869/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9871=`awk -v ORS=, '$1 ~ /^9871/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9879=`awk -v ORS=, '$1 ~ /^9879/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9887=`awk -v ORS=, '$1 ~ /^9887/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9911=`awk -v ORS=, '$1 ~ /^9911/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9944=`awk -v ORS=, '$1 ~ /^9944/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc9947=`awk -v ORS=, '$1 ~ /^9947/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
    acc10015=`awk -v ORS=, '$1 ~ /^10015/ {print $1}' nonNLR-OGs/"$ognumber".group | sed 's/,$/\n/g'`;
  fi;
printf "$line\t$acc108\t$acc1925\t$acc5784\t$acc5993\t$acc6899\t$acc6906\t$acc6909\t$acc6924\t$acc6939\t$acc6974\t$acc6981\t$acc7058\t$acc7063\t$acc7067\t$acc7111\t$acc7167\t$acc7186\t$acc7213\t$acc7273\t$acc7288\t$acc7308\t$acc7322\t$acc7328\t$acc7373\t$acc7396\t$acc7413\t$acc7415\t$acc7416\t$acc7417\t$acc9100\t$acc9134\t$acc9332\t$acc9518\t$acc9533\t$acc9536\t$acc9537\t$acc9542\t$acc9543\t$acc9545\t$acc9549\t$acc9550\t$acc9554\t$acc9557\t$acc9580\t$acc9583\t$acc9597\t$acc9600\t$acc9610\t$acc9654\t$acc9658\t$acc9669\t$acc9721\t$acc9762\t$acc9764\t$acc9784\t$acc9792\t$acc9837\t$acc9869\t$acc9871\t$acc9879\t$acc9887\t$acc9911\t$acc9944\t$acc9947\t$acc10015\n";
done | sort -t$'\t' -k8,8 -k12,12 -k44,44 -k53,53 >> bash-output-files/og-contig-files/network/OG_Contiguity_more_than_1_contig_linkage_evidences/clusterorderedOGs_"$fname".out;
done;

