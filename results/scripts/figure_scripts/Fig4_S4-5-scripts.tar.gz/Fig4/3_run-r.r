#!/usr/bin/env Rscript

#Figures S5. UpSet plots showing co-occurring OGs across 65 accessions
#No threshold is imposed here. Minimum threshold of 10 can be easily deduced visualizing a vertical line at 10 in sets sizes
#Input files: Binary matrices living in 'bash-output-files/og-contig-files/og-mappings/bin_trnsp_matrix_*.tsv
#Output files: 2x .svg files used for Figures S5.
#Output needs to be combined using inkscape or any similar software.
#R dependencies: UpSetR_1.3.3

#To install required libraries
#install.packages("UpSetR") 

#Load libraries
library(UpSetR)
#library(grid)
#library(gridExtra)

#Set and retrieve working directory. Replace '~' with the path to the uncompressed online material.
#setwd("~/")
#getwd()

#Load data for upsetR plots
#m197 <- read.csv("bash-output-files/og-contig-files/og-mappings/bin_trnsp_matrix_197.1.tsv",header=TRUE, sep = "\t", check.names = F)
#m208 <- read.csv("bash-output-files/og-contig-files/og-mappings/bin_trnsp_matrix_208.1.tsv",header=TRUE, sep = "\t", check.names = F)
m204 <- read.csv("bash-output-files/og-contig-files/og-mappings/bin_trnsp_matrix_204.1.tsv",header=TRUE, sep = "\t", check.names = F)
m205 <- read.csv("bash-output-files/og-contig-files/og-mappings/bin_trnsp_matrix_205.1.tsv",header=TRUE, sep = "\t", check.names = F)
#m147 <- read.csv("bash-output-files/og-contig-files/og-mappings/bin_trnsp_matrix_147.1.tsv",header=TRUE, sep = "\t", check.names = F)
#m148 <- read.csv("bash-output-files/og-contig-files/og-mappings/bin_trnsp_matrix_148.1.tsv",header=TRUE, sep = "\t", check.names = F)
#m102_8 <- read.csv("bash-output-files/og-contig-files/og-mappings/bin_trnsp_matrix_102.8.tsv",header=TRUE, sep = "\t", check.names = F)
#m211 <- read.csv("bash-output-files/og-contig-files/og-mappings/bin_trnsp_matrix_211.1.tsv",header=TRUE, sep = "\t", check.names = F)

#categorize data into factors
#m197$xIdentifier <- factor(m197$xIdentifier,levels=m197$xIdentifier)
#m208$xIdentifier <- factor(m208$xIdentifier,levels=m208$xIdentifier)
m204$xIdentifier <- factor(m204$xIdentifier,levels=m204$xIdentifier)
m205$xIdentifier <- factor(m205$xIdentifier,levels=m205$xIdentifier)
#m147$xIdentifier <- factor(m147$xIdentifier,levels=m147$xIdentifier)
#m148$xIdentifier <- factor(m148$xIdentifier,levels=m148$xIdentifier)
#m102_8$xIdentifier <- factor(m102_8$xIdentifier,levels=m102_8$xIdentifier)
#m211$xIdentifier <- factor(m211$xIdentifier,levels=m211$xIdentifier)

#Create directory to save plots
dir.create(file.path("output-plots"), showWarnings = FALSE)

#save Plots
svg(filename="output-plots/OG205_co-occurrences_gt_1.svg",
    width=9,
    height=4.5)
upset205 <- upset(m205, 
                  nsets=100,
                  scale.intersections = "identity",
                  scale.sets="identity",
                  point.size=6,
                  line.size=0,
                  matrix.color = "black",
                  main.bar.color = "black",
                  sets.bar.color = "black",
                  matrix.dot.alpha = 0.4, 
                  mainbar.y.label = "Intersection Size\n()",
                  sets.x.label = "number accessions",
                  mb.ratio = c(0.3,0.7),
                  order.by = c("freq"),
                  text.scale = c(0,1.8,0,1.5,2.2,0),
                  #text.scale = c(y.title, y.axis, x.title, x.axis, sets.names, barplot.labels)
                  number.angles = 0,
                  keep.order = F)
dev.off()

svg(filename="output-plots/OG204_co-occurrences_gt_1.svg",
    width=8.172,
    height=4.5)
upset204 <- upset(m204, 
                  nsets=100,
                  scale.intersections = "identity",
                  scale.sets="identity",
                  point.size=6,
                  line.size=0,
                  matrix.color = "black",
                  main.bar.color = "black",
                  sets.bar.color = "black",
                  matrix.dot.alpha = 0.4, 
                  mainbar.y.label = "Intersection Size\n()",
                  sets.x.label = "number accessions",
                  mb.ratio = c(0.3,0.7),
                  order.by = c("freq"),
                  text.scale = c(0,1.8,0,1.5,2.2,0),
                  #text.scale = c(y.title, y.axis, x.title, x.axis, sets.names, barplot.labels)
                  number.angles = 0,
                  keep.order = F)
dev.off()


#svg(filename="output-plots/OG147_co-occurrences_gt_1.svg",
    width=13.97,
    height=12.4)
#upset147 <- upset(m147, 
                  nsets=100,
                  scale.intersections = "identity",
                  scale.sets="identity",
                  point.size=6,
                  line.size=0,
                  matrix.color = "black",
                  main.bar.color = "black",
                  sets.bar.color = "black",
                  matrix.dot.alpha = 0.4, 
                  mainbar.y.label = "Intersection Size\n()",
                  sets.x.label = "number accessions",
                  mb.ratio = c(0.5,0.5),
                  order.by = c("freq"),
                  text.scale = c(0,1.8,0,1.5,2.2,0),
                  #text.scale = c(y.title, y.axis, x.title, x.axis, sets.names, barplot.labels)
                  number.angles = 0,
                  keep.order = F)
#dev.off()

#svg(filename="output-plots/OG148_co-occurrences_gt_1.svg",
    width=13.97,
    height=12.4)
#upset148 <- upset(m148, 
                  nsets=100,
                  scale.intersections = "identity",
                  scale.sets="identity",
                  point.size=6,
                  line.size=0,
                  matrix.color = "black",
                  main.bar.color = "black",
                  sets.bar.color = "black",
                  matrix.dot.alpha = 0.4, 
                  mainbar.y.label = "Intersection Size\n()",
                  sets.x.label = "number accessions",
                  mb.ratio = c(0.5,0.5),
                  order.by = c("freq"),
                  text.scale = c(0,1.8,0,1.5,2.2,0),
                  #text.scale = c(y.title, y.axis, x.title, x.axis, sets.names, barplot.labels)
                  number.angles = 0,
                  keep.order = F)
#dev.off()


#svg(filename="output-plots/OG197_co-occurrences_gt_1.svg",
    width=9.828,
    height=5.2)
#upset197 <- upset(m197, 
                  nsets=100,
                  scale.intersections = "identity",
                  scale.sets="identity",
                  point.size=6,
                  line.size=0,
                  matrix.color = "black",
                  main.bar.color = "black",
                  sets.bar.color = "black",
                  matrix.dot.alpha = 0.4, 
                  mainbar.y.label = "Intersection Size\n()",
                  sets.x.label = "number accessions",
                  mb.ratio = c(0.3,0.7),
                  order.by = c("freq"),
                  text.scale = c(0,1.8,0,1.5,2.2,0),
                  #text.scale = c(y.title, y.axis, x.title, x.axis, sets.names, barplot.labels)
                  number.angles = 0,
                  keep.order = F)
#dev.off()

#svg(filename="output-plots/OG208_co-occurrences_gt_1.svg",
    width=9,
    height=5.2)
#upset208 <- upset(m208, 
                  nsets=100,
                  scale.intersections = "identity",
                  scale.sets="identity",
                  point.size=6,
                  line.size=0,
                  matrix.color = "black",
                  main.bar.color = "black",
                  sets.bar.color = "black",
                  matrix.dot.alpha = 0.4, 
                  mainbar.y.label = "Intersection Size\n()",
                  sets.x.label = "number accessions",
                  mb.ratio = c(0.3,0.7),
                  order.by = c("freq"),
                  text.scale = c(0,1.8,0,1.5,2.2,0),
                  #text.scale = c(y.title, y.axis, x.title, x.axis, sets.names, barplot.labels)
                  number.angles = 0,
                  keep.order = F)
#dev.off()


#svg(filename="output-plots/OG102.8_co-occurrences_gt_1.svg",
    width=7.758,
    height=5.5)
#upset102_8 <- upset(m102_8, 
                    nsets=100,
                    scale.intersections = "identity",
                    scale.sets="identity",
                    point.size=6,
                    line.size=0,
                    matrix.color = "black",
                    main.bar.color = "black",
                    sets.bar.color = "black",
                    matrix.dot.alpha = 0.4, 
                    mainbar.y.label = "Intersection Size\n()",
                    sets.x.label = "number accessions",
                    mb.ratio = c(0.5,0.5),
                    order.by = c("freq"),
                    text.scale = c(0,1.8,0,1.5,2.2,0),
                    #text.scale = c(y.title, y.axis, x.title, x.axis, sets.names, barplot.labels)
                    number.angles = 0,
                    keep.order = F)
#dev.off()

#svg(filename="output-plots/OG211_co-occurrences_gt_1.svg",
    width=6.516,
    height=5.5)
#upset211 <- upset(m211,
                  nsets=100,
                  scale.intersections = "identity",
                  scale.sets="identity",
                  point.size=6,
                  line.size=0,
                  matrix.color = "black",
                  main.bar.color = "black",
                  sets.bar.color = "black",
                  matrix.dot.alpha = 0.4, 
                  mainbar.y.label = "Intersection Size\n()",
                  sets.x.label = "number accessions",
                  mb.ratio = c(0.5,0.5),
                  order.by = c("freq"),
                  text.scale = c(0,1.8,0,1.5,2.2,0),
                  #text.scale = c(y.title, y.axis, x.title, x.axis, sets.names, barplot.labels)
                  number.angles = 0,
                  keep.order = F)
#dev.off()

# check whether the unwanted file exists and remove it
#file.exists("Rplots.pdf")
#file.remove("Rplots.pdf")
