#!/usr/bin/env Rscript

#Figure 2. Barplots and accumulation plot

#Input files for panels bcef: ArchitecturesVsKnownIDs.tsv (Table S___), SITable-Architectures.tsv (Table S___) and SITable-Domains.tsv  (Table S___).
#Input files for panels ad: UpSetR-Architectures.tsv (Table S___) and UpSetR-IDs.tsv (Table S___).
#Output files: Figure 2 2x(.svg, .png, .pdf); Figure S2 1x(.svg, .png, .pdf).
#Output needs to be merged in order to obtain Figure 2.
#R dependencies: UpSetR_1.3.3, cowplot_0.9.3, gsubfn_0.7, proto_1.0.0, reshape2_1.4.3, gridExtra_2.3, ggplot2_3.1.0 

#To install required libraries
#install.packages(c("UpSetR", "ggplot2","gridExtra","reshape2","gsubfn","cowplot")) 

#Load libraries
library(UpSetR)
library(ggplot2)
library(gridExtra)
library(grid)
library(reshape2)
library(gsubfn)
library(cowplot)

#Set and retrieve working directory. Replace '~' with the path to the uncompressed online material.
#setwd("~/")
#getwd()

#Load data for panel 'a'. This file is needed and cannot be replaced with Domains-metadata.tsv. The latter does not contain IDs from Brassicace NLRs.
datadom <- read.csv("bash-output-files/UpSetR-IDs.tsv",header=TRUE, sep = "\t", check.names = F)

#Load data for panel 'f'
ids <- read.csv("bash-output-files/ArchitecturesVsKnownIDs.tsv",header=T,sep="\t",check.names=F)
ids$Name <- factor(ids$Name,levels=ids$Name)
meltids <- melt(ids,id.vars="Name",measure.vars=c("Novel_archs(not_brassic)","Known_archs(in_brassic)"))

#Load data for panels 'c' and 'e'
arch <- read.csv("bash-output-files/SITable-Architectures.tsv",header=TRUE, sep = "\t")

#Load data for panel 'd'
datarch <- read.csv("bash-output-files/UpSetR-Architectures.tsv",header=TRUE, sep = "\t", check.names = F)

#Load data for panels 'b'
dom <- read.csv("bash-output-files/SITable-Domains.tsv",header=TRUE, sep = "\t")

#Parse Architectures Intersection for barplot  
archintCol <- arch[which(arch$Collapsed_Arch_in_Col.0=='0') ,]
archintCol$Collapsed_Arch <- factor(archintCol$Collapsed_Arch,levels=archintCol$Collapsed_Arch)
archintCol$domains <- gsubfn("\\w+",list("PF08381" = "BRX","PF02671" = "PAH","PF03106" = "WRKY","PF00069" = "Pkinase","PF04548" = "AIG1","PF05553" = "DUF761","PF03634" = "TCP","PF02362" = "B3","PF00642" = "zf-CCCH","PF07887" = "Calmodulin_bind","PF13442" = "Cytochrome_CBB3","PF00412" = "LIM","PF12315" = "DA1-like","PF07714" = "Pkinase_Tyr","PF04859" = "DUF641","PF01535" = "PPR","PF06552" = "TOM20_plant","PF06984" = "MRP-L47","PF01415" = "IL7","PF13041" = "PPR_2","PF00743" = "FMO-like","PF08268" = "FBA_3","PF04864" = "Alliinase_C","PF01485" = "IBR","PF01434" = "Peptidase_M41","PF00170" = "bZIP_1","PF03501" = "S10_plectin","PF00380" = "Ribosomal_S9","PF00004" = "AAA","PF14223" = "Retrotran_gag_2","PF03637" = "Mob1_phocein","PF14363" = "AAA_assoc","PF01451" = "LMWPc"), as.character(archintCol$Collapsed_Arch))
e <- gsubfn("\\w+",list("NA" = "-"), as.character(round(as.numeric(gsubfn("\\w+",list("-" = "NA"), as.character(archintCol$pair_putpair_ratio))),digits = 2)))

archintCol2 <- arch[which(arch$Collapsed_Arch_in_Col.0=='0' & arch$size>1) ,]
archintCol2$Collapsed_Arch <- factor(archintCol2$Collapsed_Arch,levels=archintCol2$Collapsed_Arch)
archintCol2$domains <- gsubfn("\\w+",list("PF08381" = "BRX","PF02671" = "PAH","PF03106" = "WRKY","PF00069" = "Pkinase","PF04548" = "AIG1","PF05553" = "DUF761","PF03634" = "TCP","PF02362" = "B3","PF00642" = "zf-CCCH","PF07887" = "Calmodulin_bind","PF13442" = "Cytochrome_CBB3","PF00412" = "LIM","PF12315" = "DA1-like","PF07714" = "Pkinase_Tyr","PF04859" = "DUF641","PF01535" = "PPR","PF06552" = "TOM20_plant","PF06984" = "MRP-L47","PF01415" = "IL7","PF13041" = "PPR_2","PF00743" = "FMO-like","PF08268" = "FBA_3","PF04864" = "Alliinase_C","PF01485" = "IBR","PF01434" = "Peptidase_M41","PF00170" = "bZIP_1","PF03501" = "S10_plectin","PF00380" = "Ribosomal_S9","PF00004" = "AAA","PF14223" = "Retrotran_gag_2","PF03637" = "Mob1_phocein","PF14363" = "AAA_assoc","PF01451" = "LMWPc"), as.character(archintCol2$Collapsed_Arch))
m <- gsubfn("\\w+",list("NA" = "-"), as.character(round(as.numeric(gsubfn("\\w+",list("-" = "NA"), as.character(archintCol2$pair_putpair_ratio))),digits = 2)))

#Parse Domains Intersection for barplot 
domintCol2 <- dom[which(dom$`Araport11`=='1' & dom$Domain_ID!='TIR' & dom$Domain_ID!='NB' & dom$Domain_ID!='LRR' & dom$Domain_ID!='Coil' & dom$Domain_ID!='RPW8') ,]
domintCol2$Domain_ID <- factor(domintCol2$Domain_ID, levels=domintCol2$Domain_ID[order(sort(domintCol2$Size))], ordered=T)
domintCol2$Pair.Putpair_Ratio <- gsubfn("\\w+",list("NA" = "-"), as.character(round(as.numeric(gsubfn("\\w+",list("-" = "NA"), as.character(domintCol2$Pair.Putpair_Ratio))),digits = 2)))

domintCol22 <- dom[which(dom$Araport11=='0') ,]
domintCol22$Domain_ID <- factor(domintCol22$Domain_ID,levels=domintCol22$Domain_ID[order(sort(domintCol22$Size))], ordered=T)
domintCol22$Pair.Putpair_Ratio <- gsubfn("\\w+",list("NA" = "-"), as.character(round(as.numeric(gsubfn("\\w+",list("-" = "NA"), as.character(domintCol22$Pair.Putpair_Ratio))),digits = 2)))

#Plot 'a'
doms <- upset(datadom,
                scale.intersections="identity",
                scale.sets="identity",
                point.size=3,line.size=0,
                sets=c("Brassicaceae","At-pan-NLR'ome","Araport11"),
                mainbar.y.label="Intersection Size\n(shared domains)",
                sets.x.label = "Domains",
                #      mb.ratio = c(0.65,0.35),
                order.by = c("degree","freq"),
                text.scale = c(2.2,2.2,2.2,1.5,2.2,2.2),
                #text.scale = c(y.title, y.axis, x.title, x.axis, sets.names, barplot.labels)
                number.angles = 0,
                keep.order = TRUE,
                query.legend = "bottom")

#UpSetR_1.3.3 plots cannot be sored in a base R object. As a workaround we capture the graphics drawn on the default device
#capture partial grid output (workaround to remove barplots left of sets.names)
pdoms=grid.grab(warn=0,wrap=F)

#capture full grid output (as is). Not shown in the manuscript.
#grid.edit('arrange',name='arrange2')
#fdoms=grid.grab()

#Plot 'd'
archs <- upset(datarch, 
                scale.intersections = "identity",
                scale.sets="identity",
                point.size=3,line.size=0,
                sets = c("Brassicaceae","At-pan-NLR'ome","Araport11"),
                mainbar.y.label = "Intersection Size\n(shared architectures)",
                sets.x.label = "Architectures",
                #mb.ratio = c(0.79,0.21),
                order.by = c("degree","freq"),
                text.scale = c(2.2,2.2,2.2,1.5,2.2,2.2),
                #text.scale = c(y.title, y.axis, x.title, x.axis, sets.names, barplot.labels)
                number.angles = 0,
                keep.order = T,
                queries = list(list(query = elements, 
                                    params = list("ArchType", "noncanonical"), 
                                    color = "#4B9CD3", 
                                    active=T,
                                    query.name="ID-containing architectures")),
                query.legend = "bottom")

#capture partial grid output (workaround to remove barplots left of sets.names)
parchs=grid.grab(warn=0,wrap=F)

#capture full grid output (as is)
#grid.edit('arrange',name='arrange2')
#farchs=grid.grab()

#Prepare layout to combine panels 'a' and 'd'
lsplotsx <- list(pdoms,parchs)
#lsplotsy <- list(fdoms,farchs) 
layx <- cbind(c(1,1,1,1,1,1,1,1,1,2,2,2,2,2,2,2,2,2,2,2))
grid.arrange(grobs=lsplotsx,layout_matrix=layx)
#grid.arrange(grobs=lsplotsy,layout_matrix=layx)

dir.create(file.path("output-plots"), showWarnings = FALSE)

#Save SVG with panels 'a' and 'd'
svg(filename="output-plots/Fig2ad.svg",width=6,height=12)
grid.arrange(grobs=lsplotsx,layout_matrix=layx)
dev.off()

#svg(filename="output-plots/Fig2ad_full.svg",width=6,height=12)
#grid.arrange(grobs=lsplotsy,layout_matrix=layx)
#dev.off()

#Save PNG with panels 'a' and 'd'
png(filename="output-plots/Fig2ad.png",width=6,height=12,units="in",res=300,type="cairo")
grid.arrange(grobs=lsplotsx,layout_matrix=layx)
dev.off()

#png(filename="output-plots/Fig2ad_full.png",width=6,height=12,units="in",res=300,type="cairo")
#grid.arrange(grobs=lsplotsy,layout_matrix=layx)
#dev.off()

#Save PDF with panels 'a' and 'd'
cairo_pdf(filename="output-plots/Fig2ad.pdf",width=6,height=12,fallback_resolution = 300)
grid.arrange(grobs=lsplotsx,layout_matrix=layx)
dev.off()

#cairo_pdf(filename="output-plots/Fig2ad_full.pdf",width=6,height=12,fallback_resolution = 300)
#grid.arrange(grobs=lsplotsy,layout_matrix=layx)
#dev.off()


#Prepare panel 'b'
plot9 <- ggplot(domintCol22,aes(x=domintCol22$Domain_ID,y=domintCol22$Size,fill=factor(domintCol22$Araport11)))+
  geom_bar(stat="identity",width=1,colour="black",size=0.25)+
  geom_text(aes(label=Size),hjust=-0.2,size=3,angle=0)+
  geom_text(aes(label=gsubfn("\\w+",list("0"="*","1"=""),as.character(domintCol22$Brassicaceae))),vjust=0.75,hjust=-2,size=6,angle=0)+
  annotate(geom="text",x=seq_len(nrow(domintCol22)),y=-0.5,label=domintCol22$Pair.Putpair_Ratio,angle=0,hjust=1,vjust=0.5,size=3)+
  annotate(geom="text",x=seq_len(nrow(domintCol22)),y=-2.5,label=domintCol22$Pfam_identifier,angle=0,hjust=1,vjust=0.5,size=3)+
  labs(title=NULL,subtitle=NULL,y="Number of NLRs",x="Integrated Domains (IDs)")+
  scale_fill_manual(name="At-pan-NLR'ome ID", labels = c("Novel", "Known"), breaks=c("0","1"), values=c("grey","grey23"))+
  scale_x_discrete(expand=c(0,0),labels=domintCol22$domains)+
  scale_y_continuous(expand=c(0,0),breaks=seq(0,19,5),limits=c(-10,20))+
  theme(panel.background=element_blank(),
        panel.border=element_blank(),
        axis.title.y=element_text(size=16,face="bold"),
        axis.title.x=element_text(size=16,hjust=0.65,face="bold"),
        axis.text.y=element_blank(),
        axis.text.x=element_text(size=10),
        panel.grid.major.y=element_blank(),
        panel.grid.minor.y=element_blank(),
        axis.line=element_blank(),
        axis.ticks.y=element_blank(),
        axis.ticks.x=element_line(colour = "black", size =0.25),
        legend.position=c(0.858,0.96),
        legend.text=element_text(size=10,face="plain"),
        legend.title=element_blank(),
        legend.key.size=unit(4,"mm"))+
  guides(fill=guide_legend(nrow=2,byrow=F))+
  coord_flip(ylim=c(-10,20))
#plot9


plot90 <- ggplot(domintCol2,aes(x=Domain_ID,y=Size,fill=factor(Araport11)))+
  geom_bar(stat="identity",width=1,colour="black",size=0.25)+
  geom_text(aes(label=Size),hjust=-0.2,size=3,angle=0)+
  geom_text(aes(label=gsubfn("\\w+",list("0"="*","1"=""),as.character(domintCol2$Brassicaceae))),vjust=0.75,hjust=-2,size=6,angle=0)+
  annotate(geom="text",x=seq_len(nrow(domintCol2)),y=-2,label=domintCol2$Pair.Putpair_Ratio,angle=0,hjust=1,vjust=0.5,size=3)+
  annotate(geom="text",x=seq_len(nrow(domintCol2)),y=-40,label=domintCol2$Pfam_identifier,angle=0,hjust=1,vjust=0.5,size=3)+
  labs(title=NULL,subtitle=NULL,y="Number of NLRs",x="Integrated Domains (IDs)")+
  scale_fill_manual(name="At-pan-NLR'ome ID", labels = "Known", breaks="1", values="grey23")+
  scale_x_discrete(expand=c(0,0),labels=domintCol2$domains)+
  scale_y_continuous(expand=c(0,0),breaks=seq(0,170,50),limits=c(-170,220))+
  theme(panel.background=element_blank(),
        panel.border=element_blank(),
        axis.title.y=element_blank(),
        axis.title.x=element_blank(),
        axis.text.y=element_blank(),
        axis.text.x=element_text(size=10),
        panel.grid.major.y=element_blank(),
        panel.grid.minor.y=element_blank(),
        axis.line=element_blank(),
        axis.ticks.y=element_blank(),
        axis.ticks.x=element_line(colour="black", size=0.25),
        legend.position=c(0.68,0.78),
        legend.text=element_text(size=10,face="plain"),
        legend.title=element_blank(),
        legend.key.size=unit(4,"mm"))+
  guides(fill=guide_legend(nrow=2,byrow=F))+
  coord_flip(ylim=c(-165,220))
#plot90

#Plot panel 'b'
box <- data.frame(
  x=0.49, y=0.61)
p1 <- ggdraw() +
  draw_plot(plot9, 0, 0, 0.96, 1) +
  draw_plot(plot90, 0.45, 0.59, 0.55, 0.41)+
  geom_rect(data = box, aes(xmin = x, xmax = x+0.5, ymin = y, ymax = y+0.38),
            colour = "black", fill = "white",alpha=0,size=0.25)
#  draw_plot_label(c("b", "c"), c(0, 0.42), c(1, 1), size = 15)
#p1


#Plot panel 'c'
plot1 <- ggplot(arch,aes(x=factor(1:97),y=cumsum(rev(sort(size))),color=Arch_Type))+
  geom_point(size=6) +
  labs(title=NULL,subtitle=NULL,y="Cumulative number\nof NLRs",x="Sorted Architectures")+
  scale_y_continuous(expand=c(0,0),breaks=c(0,6580,9870,11515,13160),limits=c(0,14000),labels=scales::comma)+
  theme(panel.border=element_blank(), 
        panel.background=element_blank(),
        axis.text.x=element_blank(),
        axis.text.y=element_text(size=10),
        legend.position=c(0.69,0.5),
        legend.title=element_blank(),
        legend.text=element_text(size=10,face="plain"),
        axis.line=element_line(colour="black",size=0.25),
        axis.ticks.y=element_line(colour="black",size=0.25),
        axis.ticks.x=element_blank(),
        axis.title.y=element_text(size=16,face="bold"),
        axis.title.x=element_text(size=16,face="bold"),
        legend.key.size=unit(4,"mm"))+
  geom_hline(yintercept=13160,linetype="dashed",size=0.25)+
  scale_color_manual(name="Architecture Type",values=c("lightcoral","#4B9CD3"), label=c("NLR","NLR-ID"))
#plot1

#Prepare panel 'e'
plot7 <- ggplot(archintCol2,aes(x=Collapsed_Arch,y=rev(sort(size)),fill=Subclass))+
  geom_bar(stat="identity",width=1,colour="black",size=0.25)+
  geom_text(aes(label=size),hjust=-0.2,size=3,angle=0)+ #Number on top of bars
  geom_text(aes(label=gsubfn("\\w+",list("0"="*","1"=""),as.character(archintCol2$Collapsed_Arch_in_Family))),vjust=0.75,hjust=-2,size=6,angle=0)+ #Asterisk on top of bars
  annotate(geom="text",x=seq_len(nrow(archintCol2)),y=-0.5,label=m,angle=0,hjust=1,vjust=0.5,size=3)+ #Pair ratio below axis
  annotate(geom="text",x=seq_len(nrow(archintCol2)),y=-6,label=archintCol2$domains,angle=0,hjust=1,vjust=0.5,size=3)+ # Discrete Architectures below axis
  labs(title=NULL,subtitle=NULL,y="Number of NLRs",x="Domain Architectures")+
  scale_fill_manual(values=c("#0348b0","#1d76fc","#81b3fd","#0e6f25","#50a33e","#a4de9a","#573b7a","#8e71b4","#c9a8f1","#ffac00","#ffce00","#ffdf00","#fff100","#fff976","#fffcbe"))+
  scale_x_discrete(expand=c(0,0),labels=archintCol2$domains)+
  scale_y_continuous(expand=c(0,0),breaks=seq(0,100,10),limits=c(-37,110))+
  theme(panel.background=element_blank(),
        panel.border=element_blank(),
        axis.title.y=element_text(size=16,face="bold"),
        axis.title.x=element_text(size=16,hjust=0.75,face="bold"),
        axis.text.y=element_blank(),
        axis.text.x=element_text(size=10),
        panel.grid.major.y=element_blank(),
        panel.grid.minor.y=element_blank(),
        axis.line=element_blank(),
        axis.ticks.y=element_blank(),
        axis.ticks.x=element_line(colour = "black", size =0.25),
        legend.position=c(0.6,0.85),
        legend.text=element_text(size=10,face="plain"),
        legend.title=element_blank(),
        legend.key.size=unit(4,"mm"))+
  guides(fill=guide_legend(ncol=2,byrow=F))+
  coord_flip(ylim=c(-65,115))
#plot7

plot7A <- ggplot(archintCol2,aes(x=Collapsed_Arch,y=rev(sort(size)),fill=Subclass))+
  geom_bar(stat="identity",width=1,colour="black",size=0.25)+
  geom_text(aes(label=size),hjust=-0.2,size=3,angle=0)+ #Number on top of bars
  geom_text(aes(label=gsubfn("\\w+",list("0"="*","1"=""),as.character(archintCol2$Collapsed_Arch_in_Family))),vjust=0.75,hjust=-2,size=6,angle=0)+ #Asterisk on top of bars
  annotate(geom="text",x=seq_len(nrow(archintCol2)),y=-0.5,label=m,angle=0,hjust=1,vjust=0.5,size=3)+ #Pair ratio below axis
  annotate(geom="text",x=seq_len(nrow(archintCol2)),y=-6,label=archintCol2$domains,angle=0,hjust=1,vjust=0.5,size=3)+ # Discrete Architectures below axis
  labs(title=NULL,subtitle=NULL,y="Number of NLRs",x="Domain Architectures")+
  scale_fill_manual(values=c("#0348b0","#1d76fc","#81b3fd","#0e6f25","#50a33e","#a4de9a","#573b7a","#8e71b4","#c9a8f1","#ffac00","#ffce00","#ffdf00","#fff100","#fff976","#fffcbe"))+
  scale_x_discrete(expand=c(0,0),labels=archintCol2$domains)+
  scale_y_continuous(expand=c(0,0),breaks=seq(0,100,10),limits=c(-37,160))+
  theme(panel.background=element_blank(),
        panel.border=element_blank(),
        axis.title.y=element_text(size=16,face="bold"),
        axis.title.x=element_text(size=16,hjust=1.2,face="bold"),
        axis.text.y=element_blank(),
        axis.text.x=element_text(size=10),
        panel.grid.major.y=element_blank(),
        panel.grid.minor.y=element_blank(),
        axis.line=element_blank(),
        axis.ticks.y=element_blank(),
        axis.ticks.x=element_line(colour = "black", size =0.25),
        legend.position=c(0.85,0.85),
        legend.text=element_text(size=10,face="plain"),
        legend.title=element_blank(),
        legend.key.size=unit(4,"mm"))+
  guides(fill=guide_legend(ncol=2,byrow=F))+
  coord_flip(ylim=c(-37,24))
#plot7A

plot7C <- ggplot(archintCol2,aes(x=Collapsed_Arch,y=rev(sort(size)),fill=Subclass))+
  geom_bar(stat="identity",width=1,colour="black",size=0.25)+
  geom_text(aes(label=size),hjust=-0.2,size=3,angle=0)+ #Number on top of bars
  geom_text(aes(label=gsubfn("\\w+",list("0"="*","1"=""),as.character(archintCol2$Collapsed_Arch_in_Family))),vjust=0.75,hjust=-2,size=6,angle=0)+ #Asterisk on top of bars
  annotate(geom="text",x=seq_len(nrow(archintCol2)),y=-0.5,label=m,angle=0,hjust=1,vjust=0.5,size=3)+ #Pair ratio below axis
  annotate(geom="text",x=seq_len(nrow(archintCol2)),y=-6,label=archintCol2$domains,angle=0,hjust=1,vjust=0.5,size=3)+ # Discrete Architectures below axis
  labs(title=NULL,subtitle=NULL,y="Number of NLRs",x="Non-Canonical Architectures NOT in Brassicales")+
  scale_fill_manual(values=c("#0348b0","#1d76fc","#81b3fd","#0e6f25","#50a33e","#a4de9a","#573b7a","#8e71b4","#c9a8f1","#ffac00","#ffce00","#ffdf00","#fff100","#fff976","#fffcbe"))+
  scale_x_discrete(expand=c(0,0),labels=archintCol2$domains)+
  scale_y_continuous(expand=c(0,0),breaks=seq(0,100,10),limits=c(0,106))+
  theme(panel.background=element_blank(),
        panel.border=element_blank(),
        axis.title.y=element_text(size=0,face="bold"),
        axis.title.x=element_text(size=0),
        axis.text.y=element_blank(),
        axis.text.x=element_text(size=10),
        panel.grid.major.y=element_blank(),
        panel.grid.minor.y=element_blank(),
        axis.line=element_blank(),
        axis.ticks.y=element_blank(),
        axis.ticks.x=element_line(colour = "black", size =0.25),
        legend.text=element_blank(),
        legend.title=element_blank(),
        legend.key.size=unit(4,"mm"))+
  guides(fill=F)+
  coord_flip(ylim=c(98,110))
#plot7C

#Plot panel 'f'
plot11 <- ggplot() +
  geom_bar(data=meltids,aes(x=Name,y=value,fill=factor(variable,levels=c("Known_archs(in_brassic)","Novel_archs(not_brassic)"))),stat="identity",position="stack",width=1,colour="black",size=0.25)+
  geom_text(data=ids,aes(x=Name,y=ids$`Novel_archs(not_brassic)`+ids$`Known_archs(in_brassic)`+0.5,label=gsubfn("\\w+",list("1"="a","0"=""),as.character(ids$Kroj_et_al._Table_S3))),size=3,angle=0,alpha=0.8,hjust=1)+ #Asterisk on top of bars
  geom_text(data=ids,aes(x=Name,y=ids$`Novel_archs(not_brassic)`+ids$`Known_archs(in_brassic)`+0.5,label=gsubfn("\\w+",list("1"="b","0"=""),as.character(ids$Sarris_et_al._TableS14_RightP_lt_0.01))),size=3,angle=0,alpha=0.8,hjust=0)+ #Asterisk on top of bars
  labs(title=NULL,subtitle=NULL,y="Number of Architectures",x="Known Brassicaceae IDs")+
  scale_y_continuous(expand=c(0,0),breaks=seq(0,10,5),limits=c(0,16))+
  scale_fill_manual(labels=c("Known","Novel"), values=c("gray23","grey"))+
  theme(panel.background=element_blank(),
        panel.border=element_blank(),
        axis.title.y=element_text(size=16,face="bold"),
        axis.title.x=element_text(size=16,face="bold"),
        axis.text.x=element_text(size=10,angle=0,face="plain"),
        axis.text.y=element_text(size=10,angle=0,face="plain"),
        axis.line=element_blank(),
        axis.ticks.x=element_line(colour="black",size=0.25),
        axis.ticks.y=element_blank(),
        legend.position=c(0.7,0.8),
        legend.title=element_blank(),
        legend.text=element_text(size=10,face="plain"),
        legend.key.size=unit(4,"mm"))+
  guides(fill=guide_legend(nrow=2,byrow=F))+
  coord_flip()
#plot11

#Align plots for multipanel
plots <- align_plots(plot7A,p1, align='v',axis='l')
top_row <- plot_grid(plots[[2]])
bottom_row <- plot_grid(plots[[1]],plot7C,align='h',rel_widths=c(7,1.6))
col2 <- plot_grid(top_row,bottom_row,labels=c('b', 'e'),label_size=24,ncol=1,rel_heights=c(0.8,1))
col3 <- plot_grid(plot1,plot11,ncol=1,align="v",labels=c('c', 'f'),label_size=24,rel_heights = c(0.8,1))

#Save PNG with panels 'b', 'c', 'e' and 'f'
png(filename="output-plots/Fig2bcef.png",width=12,height=11,units="in",res=300,type="cairo")
plot_grid(col2,col3,nrow=1,rel_widths=c(1,1))
dev.off()

#Save SVG with panels 'b', 'c', 'e' and 'f'
svg(filename="output-plots/Fig2bcef.svg",width=12,height=11)
plot_grid(col2,col3,nrow=1,rel_widths=c(1,1))
dev.off()

#Save PDF with panels 'b', 'c', 'e' and 'f'
cairo_pdf(filename="output-plots/Fig2bcef.pdf",width=12,height=11,fallback_resolution = 300)
plot_grid(col2,col3,nrow=1,rel_widths=c(1,1))
dev.off()

#Plot Supplementary Figure with full list of novel A. thaliana architectures 
plotSfl <- ggplot(archintCol,aes(x=Collapsed_Arch,y=rev(sort(size)),fill=Subclass))+
  geom_bar(stat="identity",width=1,colour="black",size=0.25)+
  geom_text(aes(label=size),hjust=-0.2,size=3,angle=0)+ #Number on top of bars
  geom_text(aes(label=gsubfn("\\w+",list("0"="*","1"=""),as.character(archintCol$Collapsed_Arch_in_Family))),vjust=0.75,hjust=-2,size=6,angle=0)+ #Asterisk on top of bars
  annotate(geom="text",x=seq_len(nrow(archintCol)),y=-0.5,label=e,angle=0,hjust=1,vjust=0.5,size=3)+ #Pair ratio below axis
  annotate(geom="text",x=seq_len(nrow(archintCol)),y=-6,label=archintCol$domains,angle=0,hjust=1,vjust=0.5,size=3)+ # Discrete Architectures below axis
  labs(title=NULL,subtitle=NULL,y="Number of NLRs",x="Domain Architectures")+
  scale_fill_manual(values=c("#011f4b","#0348b0","#1d76fc","#81b3fd","#0e6f25","#50a33e","#a4de9a","#3a2458","#573b7a","#6b528b","#8e71b4","#c9a8f1","#eee6f4","#ff9b00","#ffac00","#ffce00","#ffdf00","#fff100","#fff976","#fffcbe"))+
  scale_x_discrete(expand=c(0,0),labels=archintCol2$domains)+
  scale_y_continuous(expand=c(0,0),breaks=seq(0,100,10),limits=c(-37,160))+
  theme(panel.background=element_blank(),
        panel.border=element_blank(),
        axis.title.y=element_text(size=16,face="bold"),
        axis.title.x=element_text(size=16,hjust=1.2,face="bold"),
        axis.text.y=element_blank(),
        axis.text.x=element_text(size=10),
        panel.grid.major.y=element_blank(),
        panel.grid.minor.y=element_blank(),
        axis.line=element_blank(),
        axis.ticks.y=element_blank(),
        axis.ticks.x=element_line(colour = "black", size =0.25),
        legend.position=c(0.85,0.85),
        legend.text=element_text(size=10,face="plain"),
        legend.title=element_blank(),
        legend.key.size=unit(4,"mm"))+
  guides(fill=guide_legend(ncol=2,byrow=F))+
  coord_flip(ylim=c(-37,24))
#plotSfl

plotSfr <- ggplot(archintCol,aes(x=Collapsed_Arch,y=rev(sort(size)),fill=Subclass))+
  geom_bar(stat="identity",width=1,colour="black",size=0.25)+
  geom_text(aes(label=size),hjust=-0.2,size=3,angle=0)+ #Number on top of bars
  geom_text(aes(label=gsubfn("\\w+",list("0"="*","1"=""),as.character(archintCol$Collapsed_Arch_in_Family))),vjust=0.75,hjust=-2,size=6,angle=0)+ #Asterisk on top of bars
  annotate(geom="text",x=seq_len(nrow(archintCol)),y=-0.5,label=e,angle=0,hjust=1,vjust=0.5,size=3)+ #Pair ratio below axis
  annotate(geom="text",x=seq_len(nrow(archintCol)),y=-6,label=archintCol$domains,angle=0,hjust=1,vjust=0.5,size=3)+ # Discrete Architectures below axis
  labs(title=NULL,subtitle=NULL,y="Number of NLRs",x="Domain Architectures")+
  scale_fill_manual(values=c("#011f4b","#0348b0","#1d76fc","#81b3fd","#0e6f25","#50a33e","#a4de9a","#3a2458","#573b7a","#6b528b","#8e71b4","#c9a8f1","#eee6f4","#ff9b00","#ffac00","#ffce00","#ffdf00","#fff100","#fff976","#fffcbe"))+
  scale_x_discrete(expand=c(0,0),labels=archintCol2$domains)+
  scale_y_continuous(expand=c(0,0),breaks=seq(0,100,10),limits=c(0,106))+
  theme(panel.background=element_blank(),
        panel.border=element_blank(),
        axis.title.y=element_text(size=0,face="bold"),
        axis.title.x=element_text(size=0),
        axis.text.y=element_blank(),
        axis.text.x=element_text(size=10),
        panel.grid.major.y=element_blank(),
        panel.grid.minor.y=element_blank(),
        axis.line=element_blank(),
        axis.ticks.y=element_blank(),
        axis.ticks.x=element_line(colour = "black", size =0.25),
        legend.text=element_blank(),
        legend.title=element_blank(),
        legend.key.size=unit(4,"mm"))+
  guides(fill=F)+
  coord_flip(ylim=c(98,110))
#plotSfr

#Save PNG with SF2c
svg(filename="output-plots/FigS2c.svg",width=6,height=11)
plot_grid(plotSfl,plotSfr,align='h',rel_widths=c(7,1.6))
dev.off()

png(filename="output-plots/FigS2c.png",width=6,height=11,units="in",res=300,type="cairo")
plot_grid(plotSfl,plotSfr,align='h',rel_widths=c(7,1.6))
dev.off()

cairo_pdf(filename="output-plots/FigS2c.pdf",width=6,height=11,fallback_resolution = 300)
plot_grid(plotSfl,plotSfr,align='h',rel_widths=c(7,1.6))
dev.off()

# check whether the unwanted file exists and remove it
file.exists("Rplots.pdf")
file.remove("Rplots.pdf")

