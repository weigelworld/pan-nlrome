#Shipped material:
####bash and r scripts
```bash
**1_run-bash.sh**	#in-house bash parser (see below)
**2_run-r.r**	#in-house Fig2 and S2 r script (see below)
```
####bash-input-files/
```bash
bash-input-files/
|	12915_2016_228_MOESM14_ESM.csv #Sarris et al. BMC Biology 2016 Additional file 14: 'https://static-content.springer.com/esm/art%3A10.1186%2Fs12915-016-0228-7/MediaObjects/12915_2016_228_MOESM14_ESM.xlsx'
|	all_Rgenes.interpro_cc_majvote.tsv.sort.renamed #concatenated 'https://github.com/weigelworld/pan-nlrome/tree/master/results/annotation/domains/', except '6909_RenSeq.NLR.domains.tsv'
|	brassicaceae_R_genes.architectures.tsv #Table S_all-brassic-archs 'https://docs.google.com/spreadsheets/d/1-LdYAOzShgf1CZ9I_yU3_0c98MqmU1xZoo-SagKuFYQ/edit#gid=1837757026'
|	Kroj_NewPhytologist_TableS3_90_putative_integrated_decoys #Kroj et al. New Phytol. 2016 Table S3: 'https://nph.onlinelibrary.wiley.com/action/downloadSupplement?doi=10.1111%2Fnph.13869&file=nph13869-sup-0004-TableS3.xls'
|	Pfam-A.clans.tsv #Pfam database 'ftp://ftp.ebi.ac.uk/pub/databases/Pfam/releases/Pfam31.0/Pfam-A.clans.tsv.gz'
|	transcript_metadata.tsv #github metadata

```
#Obtaining Fig. 2 and Fig. S2
1. Open terminal and access the directory containing `Fig2` directory.
2. Mark `1_run-bash.sh` and `2_run-r.r` files as executable with the `chmod` command.
3. Execute `1_run-bash.sh`. 
4. Output will be saved in `bash-output-files/`
5. Execute `2_run-r.r`. 
6. Plots will be saved in `output-plots/`. Namely:
>`output-plots/Fig2ad.pdf`
>`output-plots/Fig2ad.png`
>`output-plots/Fig2ad.svg`
>`output-plots/Fig2bcef.pdf`
>`output-plots/Fig2bcef.png`
>`output-plots/Fig2bcef.svg`
>`output-plots/FigS2c.pdf`
>`output-plots/FigS2c.png`
>`output-plots/FigS2c.svg`
5. Plots can be combined in [inkscape](https://inkscape.org/) or similar software.
