#!/bin/bash
#This simple script generates the required tables for the R-plots in Figure2 and corresponding Dupplementary figures. 
#Check Brassicacea architecture and species metadata for details on the mined NLRs.

#Clean up previous analysis
rm -r bash-output-files/
mkdir bash-output-files

#Input files location
input="bash-input-files/transcript_metadata.tsv";
bradoms="bash-input-files/brassicaceae_R_genes.architectures.tsv";
clans="bash-input-files/Pfam-A.clans.tsv";
idkroj="bash-input-files/Kroj_NewPhytologist_TableS3_90_putative_integrated_decoys";
idsarris="bash-input-files/12915_2016_228_MOESM14_ESM.csv";
pfamipreq="bash-input-files/all_Rgenes.interpro_cc_majvote.tsv.sort.renamed";

#Output files location
output1="bash-output-files/SITable-Architectures.tsv";
output2="bash-output-files/UpSetR-Architectures.tsv";
output3="bash-output-files/SITable-Domains.tsv";
output4="bash-output-files/ArchitecturesVsKnownIDs.tsv";
output5="bash-output-files/UpSetR-Domains.tsv";
output6="bash-output-files/UpSetR-IDs.tsv";

#Other variables
totgenes=`awk 'NR>1 && $1 !~ /^6909\T|^ALYR|^CRUB/ {print $1}' "$input" | sort -u | wc -l`;
canonicalgenes=`awk 'NR>1 && $1 !~ /^6909\T|^ALYR|^CRUB/ && $7 ~ /^canonical$/ {print $1}' "$input" | sort -u | wc -l`;
noncanonigenes=`awk 'NR>1 && $1 !~ /^6909\T|^ALYR|^CRUB/ && $7 ~ /^noncanonical$/ {print $1}' "$input" | sort -u | wc -l`;

#Line_by_line_architecture census
printf "Collapsed_Arch\tsize\tsize_ratio\tArch_Type\tArchType_ratio\tTranscript\tSubclass\tCombined_Subclasses\tpair_putpair_size\tpair_putpair_ratio\tpair_putpair_transcripts\ttranscripts_assigned_to_OGs\tNumber_different_OGs\ttranscripts_assigned_to_refinedOGs\tNumber_different_refinedOGs\tCollapsed_Arch_in_Col-0\tCollapsed_Arch_in_Family\tnumber_accessions\n" > "$output1";
awk 'NR>1 && $1 !~ /^6909\T|^ALYR|^CRUB/ {print $4}' "$input" | sort -u | while read line; do 
archtype=`echo "$line" | grep -c 'PF'`; if [ $archtype = "0" ]; then archtype="canonical"; else archtype="noncanonical"; fi; 
count=`awk -v l="$line" 'NR>1 && $1 !~ /^6909\T|^ALYR|^CRUB/ && $4 == l {print $0}' "$input" | wc -l`; 
ratio=`echo "scale=6; $count/$totgenes" | bc`; 
genes=`awk -v l="$line" -v ORS=\; 'NR>1 && $1 !~ /^6909\T|^ALYR|^CRUB/ && $4 == l {print $1}' "$input" | sed 's/\;$/\n/'`; 
if [ $archtype = "canonical" ]; then ratioarch=`echo "scale=6; $count/$totgenes" | bc`; else ratioarch=`echo "scale=6; $count/$totgenes" | bc`; fi; 
class=`awk -v l="$line" 'NR>1 && $1 !~ /^6909\T|^ALYR|^CRUB/ && $4 == l {print $5}' "$input" | sort -u`; 
classog=`awk -v l="$line" 'NR>1 && $1 !~ /^6909\T|^ALYR|^CRUB/ && $4 == l {print $6}' "$input" | sort -u`; 
pairnumb=`awk -v l="$line" 'NR>1 && $1 !~ /^6909\T|^ALYR|^CRUB/ && $4 == l {if ($14==1 || $15==1) {print $1}}' "$input" | wc -l`; 
pairgen=`awk -v l="$line" -v ORS=\; 'NR>1 && $1 !~ /^6909\T|^ALYR|^CRUB/ && $4 == l {if ($14==1 || $15==1) {print $1}}' "$input" | sed 's/\;$/\n/'`;
if [ "$pairnumb" -eq 0 ]; then pairgen=-; ratiopair=0; else ratiopair=`echo "scale=6; $pairnumb/$count" | bc`; fi; 
ogens=`awk -v l="$line" 'NR>1 && $1 !~ /^6909\T|^ALYR|^CRUB/ && $4 == l && $8 !~ /^NA$/ {print $1}' "$input" | wc -l`;
noogs=`awk -v l="$line" 'NR>1 && $1 !~ /^6909\T|^ALYR|^CRUB/ && $4 == l && $8 !~ /^NA$/ {print $8}' "$input" | sort -u | wc -l`; 
refogens=`awk -v l="$line" 'NR>1 && $1 !~ /^6909\T|^ALYR|^CRUB/ && $4 == l && $10 !~ /^NA$/ {print $1}' "$input" | wc -l`;
refnoogs=`awk -v l="$line" 'NR>1 && $1 !~ /^6909\T|^ALYR|^CRUB/ && $4 == l && $10 !~ /^NA$/ {print $10}' "$input" | sort -u | wc -l`; 
col=`awk -v ORS=\; -v l="$line" 'NR>1 && $1 !~ /^6909\T|^ALYR|^CRUB/ && $4 == l {print $1}' "$input" | sed 's/\;$/\n/' | grep -c '6909|AT'`; 
if [ $col -gt 0 ]; then sp=1; else sp=0; fi;
f=`awk -F'\t' -v ar=$line '$3 == ar {print $1}' "$bradoms" | wc -l`; if [ $f -gt 0 ]; then family=1; else family=0; fi; 
nbacc=`awk -v l="$line" 'NR>1 && $1 !~ /^6909\T|^ALYR|^CRUB/ && $4 == l {print $0}' "$input" | awk -F\| '{print $1}' | sort -u | wc -l`
printf "$line\t$count\t$ratio\t$archtype\t$ratioarch\t$genes\t$class\t$classog\t$pairnumb\t$ratiopair\t$pairgen\t$ogens\t$noogs\t$refogens\t$refnoogs\t$sp\t$family\t$nbacc\n"; done | sort -k2,2rn >> "$output1"

#Update UpSetR ARCHITECTURE intersections:
#Concatenate RenSeq and Brassicaceae Architectures
awk -F'\t' 'NR>1 && $1 !~ /^6909\T|^ALYR|^CRUB/ {print $4}' "$input" | sort -u > tmp.list
awk -F'\t' '{print $3}' "$bradoms" | sort -u >> tmp.list
sort -u tmp.list > RenSeq_and_Brassicaceae_Archs.list;
rm tmp.list
#Presence absence matrix with ALL domains (ALL BRASSICACEAE IDS)
printf "Architecture\tArchType\tpan-NLR'ome_size\tPaired_NLRs_size\tPaired_NLRs_ratio\tPaired_ratio_val\tAt-pan-NLR'ome\tAraport11\tBrassicaceae\n" > "$output2"; cat RenSeq_and_Brassicaceae_Archs.list | while read line; do pnb=`awk -v ar=$line '$4 == ar && $1 !~ /^6909\T|^ALYR|^CRUB/ {print $4}' "$input" | sort -u | wc -l`; pnbsize=`awk -v ar=$line '$4 == ar && $1 !~ /^6909\T|^ALYR|^CRUB/ {print $1}' "$input" | sort -u | wc -l`; pairsize=`awk -v ar=$line '$1 == ar {print $9}' "$output1"`; if [ "$pairsize" = "" ]; then pairsize=0; fi; pairatio=`awk -v ar=$line '$1 == ar {print $10}' "$output1"`; if [ "$pairatio" = "" ]; then pairatio=0; fi; col=`awk -v ar=$line '$4 == ar && $1 ~ /^6909\|AT/ {print $4}' "$input" | sort -u | wc -l`; brass=`awk -v ar=$line '$3 == ar {print $3}' "$bradoms" | sort -u | wc -l`; archtype=`echo "$line" | grep -c 'PF'`; if [ $archtype = "0" ]; then archtype="canonical"; else archtype="noncanonical"; fi; if [ "$pairsize" != "0" ]; then pairval=`echo "scale=6; $pairsize/$pnbsize" | bc`; else pairval=0; fi; printf "$line\t$archtype\t$pnbsize\t$pairsize\t$pairatio\t$pairval\t$pnb\t$col\t$brass\n"; done >> "$output2"
rm RenSeq_and_Brassicaceae_Archs.list

#Line_by_line_domain census
printf "Domain_ID\tPfam_identifier\tPfam_description\tInterpro_entry\tID\tSize\tPair/Putpair_Size\tPair/Putpair_Ratio\tAraport11_NLRs\tAraport11_Architectures\tAraport11\tBrassicaceae_NLRs\tBrassicaceae_Architectures\tBrassicaceae\tAt-pan-NLRome_NLRs\tAt-panNLR'ome_Architectures\tAt-panNLR'ome\tKroj_et_al._Table_S3\tSarris_et_al._TableS14_RightP_lt_0.01\tNumber_Accessions\n" > "$output3";
awk 'NR>1 && $1 !~ /^6909\T|^ALYR|^CRUB/ {print $4}' "$input" | sed -r 's/,/\n/g' | sort -u | while read line; # awk '$1 ~ /^PF/ {print }' 
do 
count=`awk -v l="$line" 'NR>1 && $1 !~ /^6909\T|^ALYR|^CRUB/ && $4 ~ l {print $0}' "$input" | wc -l`; 
pairnumb=`awk -v l="$line" 'NR>1 && $1 !~ /^6909\T|^ALYR|^CRUB/ && $4 ~ l {if ($14==1 || $15==1) {print $1}}' "$input" | wc -l`; 
if [ "$pairnumb" -eq 0 ]; then ratiopair=0; else ratiopair=`echo "scale=6; $pairnumb/$count" | bc`; fi;
col1=`awk -v l="$line" 'NR>1 && $1 ~ /^6909\|AT/ && $4 ~ l {print $1}' "$input" | sort -u | wc -l`; 
if [ "$col1" -gt 0 ]; then sp1=1; else sp1=0; fi;
bra1=`awk -F'\t' -v ar=$line '$3 ~ ar {print $1}' "$bradoms" | sort -u | wc -l`; 
if [ "$bra1" -gt 0 ]; then fam1=1; else fam1=0; fi; 
pan1=`awk -v l="$line" '$1 !~ /^ALYR|^CRUB|^6909\T/ && $4 ~ l {print $1}' "$input" | sort -u | wc -l`;
if [ "$pan1" -gt 0 ]; then ren1=1; else ren1=0; fi;
name=`awk -F'\t' -v l="$line" '$1 == l {print $2}' "$clans"`; 
desc=`awk -F'\t' -v l="$line" '$1 == l {print $3}' "$clans"`; 
ipr=`awk -F'\t' -v l="$line" '$5 == l {print $12}' "$pfamipreq" | sort -u`; 
if [ "$ipr" = "" ]; then ipr=NA; fi; 
if [ "$line" = "NB" ]; then name="NB-ARC"; ipr=`awk -F'\t' '$5 ~ /NB/ {print $12}' "$pfamipreq" | sort -u`; desc="NB-ARC domain"; fi
if [ "$line" = "TIR" ]; then name="TIR"; ipr=`awk -F'\t' '$5 ~ /TIR/ {print $12}' "$pfamipreq" | sort -u`; desc="TIR domain"; fi
if [ "$line" = "RPW8" ]; then name="RPW8"; ipr=`awk -F'\t' '$5 ~ /RPW8/ {print $12}' "$pfamipreq" | sort -u`; desc="Arabidopsis broad-spectrum mildew resistance protein RPW8"; fi
if [ "$line" = "LRR" ]; then name="LRR"; ipr=`awk -F'\t' '$5 ~ /LRR/ {print $12}' "$pfamipreq" | sort -u | awk -v ORS=\| '{print }' | sed 's/|$/\n/'`; desc="Leucine Rich Repeats"; fi
kroj=`awk -v i="$ipr" '$1 == i {print 1}' "$idkroj"`; 
if [ "$kroj" = "" ]; then kroj=0; fi; 
sarris=`awk -v n="$name" '$3==n && $10 < 0.01 {print 1}' "$idsarris" | sort -u`; 
if [ "$sarris" = "" ]; then sarris=0; fi; 
col2=`awk -F'\t' -v ar="$line" '$1 ~ /^6909\|AT/ && $4 ~ ar {print $4}' "$input" | sort -u | wc -l`; 
if [ "$col2" -gt 0 ]; then sp2=1; else sp2=0; fi; 
bra2=`awk -v ar=$line '$3 ~ ar {print $3}' "$bradoms" | sort -u | wc -l`; 
if [ "$bra2" -gt 0 ]; then fam2=1; else fam2=0; fi; 
pan2=`awk -v l="$line" '$1 !~ /^ALYR|^CRUB|^6909\T/ && $4 ~ l {print $4}' "$input" | sort -u | wc -l`;
if [ "$pan2" -gt 0 ]; then ren2=1; else ren2=0; fi; 
if [ "$ren1" -eq "$ren2" ]; then ren=`echo "$ren1"`; else ren=`echo "non matching arch and genes"`; fi;
if [ "$sp1" -eq "$sp2" ]; then sp=`echo "$sp1"`; else sp=`echo "non matching arch and genes"`; fi;
if [ "$fam1" -eq "$fam2" ]; then fam=`echo "$fam1"`; else fam=`echo "non matching arch and genes"`; fi;
id=`echo "$line" | grep -c "^PF"`;
nbacc=`awk -v l="$line" 'NR>1 && $1 !~ /^6909\T|^ALYR|^CRUB/ && $4 ~ l {print $0}' "$input" | awk -F\| '{print $1}' | sort -u | wc -l`;
printf "$line\t$name\t$desc\t$ipr\t$id\t$count\t$pairnumb\t$ratiopair\t$col1\t$col2\t$sp\t$bra1\t$bra2\t$fam\t$pan1\t$pan2\t$ren\t$kroj\t$sarris\t$nbacc\n";  
done | sort -t$'\t' -k6,6rn  >> "$output3"

##Create Table for Architectures Vs IDs Stacked Barplot
printf "ID\tName\tAt-pan-NLRome_Archs\tNovel_archs(not_brassic)\tKnown_archs(in_brassic)\tKroj_et_al._Table_S3\tSarris_et_al._TableS14_RightP_lt_0.01\n" > "$output4"; awk -F'\t' -v OFS='\t' '$5 == 1 && $14 == 1 && $17 == 1 {print $1,$2}' "$output3" | while IFS=$'\t\n' read pf name; do total=`awk -F'\t' -v OFS='\t' -v dom="$pf" '$1 ~ dom {print $1}' "$output1" | sort -u | wc -l`; novel=`awk -F'\t' -v OFS='\t' -v dom="$pf" '$1 ~ dom && $17 == 0 {print $1}' "$output1" | sort -u | wc -l`; notnovel=`awk -F'\t' -v OFS='\t' -v dom="$pf" '$1 ~ dom && $17 == 1 {print $1}' "$output1" | sort -u | wc -l`; name=`awk -F'\t' -v OFS='\t' -v p=$pf '$1 == p {print $2}' "$output3"`; ipr=`awk -F'\t' -v l="$pf" '$5 == l {print $12}' "$pfamipreq" | sort -u`; kroj=`awk -v i="$ipr" '$1 == i {print 1}' "$idkroj"`; if [ "$kroj" = "" ]; then kroj=0; fi; sarris=`awk -v n="$name" '$3==n && $10 < 0.01 {print 1}' "$idsarris" | sort -u`; if [ "$sarris" = "" ]; then sarris=0; fi; printf "$pf\t$name\t$total\t$novel\t$notnovel\t$kroj\t$sarris\n"; done | sort -t$'\t' -k3,3rn -k4,4rn -k1,1 >> "$output4"

##Create Table for Domain UpSetR plot
#List of domains in Brassicaceae using At-panNLR'ome pipeline: 
awk -F'\t' '{print $3}' "$bradoms" | sed -r 's/,/\n/g' | sort -u > tmp.list
#Concatenate RenSeq domains to and Brassicaceae Domains: 
awk -F'\t' 'NR>1 && $1 !~ /^6909\T|^ALYR|^CRUB/ {print $4}' "$input" | sed -r 's/,/\n/g' | sort -u >> tmp.list
#Consolidate RenSeq+Brassicaceae Domain Reunion:
sort -u tmp.list > RenSeq_and_Brassicaceae_Domains.list; 
rm tmp.list
#Presence absence matrix with ALL domains
printf "Domain\tpan-NLR'ome_size\tAt-pan-NLR'ome\tAraport11\tBrassicaceae\n" > "$output5"; cat RenSeq_and_Brassicaceae_Domains.list | while read line; do pnb=`awk -F'\t' -v ar=$line '$1 !~ /^6909\T|^ALYR|^CRUB/ && $4 ~ ar {print $4}' "$input" | sort -u | wc -l`; pnbsize=`awk -F'\t' -v ar=$line '$1 !~ /^6909\T|^ALYR|^CRUB/ && $4 ~ ar {print $1}' "$input" | sort -u | wc -l`; col=`awk -F'\t' -v ar=$line '$1 ~ /^6909\|AT/ && $4 ~ ar {print $4}' "$input" | sort -u | wc -l`; brass=`awk -v ar=$line '$3 ~ ar {print $3}' "$bradoms" | wc -l`; if [ $pnb -gt 0 ]; then pnb="1"; else pnb="0"; fi; if [ $col -gt 0 ]; then col="1"; else col="0"; fi; if [ $brass -gt 0 ]; then brass="1"; else brass="0"; fi; printf "$line\t$pnbsize\t$pnb\t$col\t$brass\n"; done >> "$output5"
rm RenSeq_and_Brassicaceae_Domains.list

#Presence absence matrix with ONLY IDs
printf "Domain\tpan-NLR'ome_size\tAt-pan-NLR'ome\tAraport11\tBrassicaceae\n" > "$output6"; awk -F'\t' '$1 ~ /^PF/ {print $0}' "$output5" >> "$output6";

